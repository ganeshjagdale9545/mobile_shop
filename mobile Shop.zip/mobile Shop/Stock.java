import java.awt.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.font.*;
import java.lang.String.*;
import java.util.*;
import java.text.*;
import java.sql.*;		
import java.awt.Graphics.*;
import javax.imageio.*;
import java.net.*;

class Stock extends JFrame implements ActionListener
{
	
	JButton b1,b2;
	
	JTable table;

	String[] colmn={"Product ID","Product Name","Product Price","Number of Product"};
	
	String[][] data=new String[100][4];
	JScrollPane scrollpane ;
	Font f=new Font("Bookman Old Style",Font.BOLD, 15);
    
    AudioClip aclip,aclip1,aclip2;
  
     Stock()
	{
		super("Stock......!!");
		b1=new JButton("Back");
		b2=new JButton("Exit");
		try
		{
		   aclip=Applet.newAudioClip(new URL("file:CASTANET.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		try
		{
		   aclip1=Applet.newAudioClip(new URL("file:GLUG.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		try
		{
		   aclip2=Applet.newAudioClip(new URL("file:ARROW.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		
				
						b1.setFont(new Font("Bookman Old Style",Font.BOLD, 15));
						b2.setFont(new Font("Bookman Old Style",Font.BOLD, 15));
	
						
		b1.setForeground(Color.blue);
		b2.setForeground(Color.blue);
		b1.setBackground(Color.cyan);
		b2.setBackground(Color.cyan);
				
		this.setSize(1280,700);
		
		this.setLayout(null);	
					
					  
					  b2.setBounds(595,620,80,25);
					  b1.setBounds(495,620,80,25);
					  try
						{	
						  Class.forName("com.mysql.jdbc.Driver");
	                       Connection   cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");
							Statement s=cn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
							ResultSet rs;						
					
							String st="select * from product";
						    rs=s.executeQuery(st);
							int i=0;
							while(rs.next())
								{
									String pid=rs.getString(1);
									String pn=rs.getString(2);
								    String pp=rs.getString(3);
									String nop=rs.getString(4);
									
									
														
											data[i][0]=pid;
											data[i][1]=pn;
											data[i][2]=pp;
											data[i][3]=nop;
											
											i++;
									}
								}
									catch(Exception ee)
									{
									}

					  
                                                    table=new JTable(data,colmn);
												   	table.setEnabled(false);
												   	table.setFont(f);
												   	table.setForeground(Color.magenta);
											        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
											       	int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
											     	scrollpane = new JScrollPane(table,v,h);
                                                                                                scrollpane.setBounds(10,10,1100,600);
											     	this.add(scrollpane);
									  
            this.add(b1);
            b1.setMnemonic('b');
            b1.setToolTipText("Press 'Alt+b' To Go Home");
			this.add(b2);
			b2.setMnemonic('e');
            b2.setToolTipText("Press 'Alt+e' To Go Home");
		
		
			
						b1.addActionListener(this);
						b2.addActionListener(this);
												
						this.setLocationRelativeTo(null);
	
		
		this.setVisible(true);
    }	
    
    public void actionPerformed(ActionEvent ae)
    {
    	if(ae.getSource()==b1)
    	{   
    	    aclip.play();
    		//new Home();
    			this.setVisible(false);
    	}
    	if(ae.getSource()==b2)
    	{              
    	                    aclip1.play();
    						new Exit();
		}
    	
    }
    
    public static void main(String str[])
    {
    	new Stock();
    }
}		
