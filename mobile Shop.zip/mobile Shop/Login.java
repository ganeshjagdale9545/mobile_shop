import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.sql.*;

class Login extends JFrame implements ActionListener
{ 
   JLabel a9,a1,a2,a3,a4,a5;
    ImageIcon img2,img,img7,img8;  
    JButton cmdLogin;
    JButton cmdBack;
   JButton cmdReset;
  JTextField t1;
   JPasswordField t2;
JLabel l4,l5;
   Connection cn;
   ResultSet rs;
   Statement st;
   Font F=new Font("Times New Roman",Font.BOLD,14);

   Login()
  {
        Container container = new Container();
        getContentPane();
        setLayout(new BorderLayout());
        setDefaultCloseOperation(0);



ImageIcon  img1=new ImageIcon("2.png");
          a9=new JLabel(img1);
  getContentPane().add(a9);
          a9.setBounds(20,0,1300,110);

/*ImageIcon  img3=new ImageIcon("sz42.png");
          a3=new JLabel(img3);
  getContentPane().add(a3);
          a3.setBounds(0,80,600,600);*/

       


    ImageIcon  img4=new ImageIcon("aa.png");
          a4=new JLabel(img4);
  getContentPane().add(a4);
          a4.setBounds(750,80,600,600);


        l4=new JLabel("User Name");
      getContentPane().add(l4);
          l4.setBounds(30,80,70,40);
         t1=new JTextField(10);
t1.setToolTipText("Enter username");
t1.setFont(F);
        getContentPane().add(t1);
          t1.setBounds(130,90,100,20);
     
        
          l5=new JLabel("Password");
           getContentPane().add(l5);
          l5.setBounds(30,105,70,40);

        
       t2=new JPasswordField(10);
t2.setToolTipText("Enter Password");
t2.setFont(F);
        getContentPane().add(t2);
          t2.setBounds(130,120,100,20);

     ImageIcon  img=new ImageIcon("LL.PNG");
          cmdLogin=new JButton(img);
  getContentPane().add(cmdLogin);
          cmdLogin.setBounds(50,170,69,38);
         cmdLogin.setVisible(true);
        cmdLogin.setEnabled(true);
        cmdLogin.addActionListener(this);
        container.add(cmdLogin);
          
   
   ImageIcon  img7=new ImageIcon("r.png");      
  cmdReset = new JButton(img7);
        cmdReset.setBounds(130, 170,69, 38);
        cmdReset.setVisible(true);
        cmdReset.setEnabled(true);
        cmdReset.addActionListener(this);
        container.add(cmdReset);

   ImageIcon  img8=new ImageIcon("E.png");        
cmdBack = new JButton(img8);
        cmdBack.setBounds(210,170,62, 38);
        cmdBack.setVisible(true);
        cmdBack.setEnabled(true);
        cmdBack.addActionListener(this);
        container.add(cmdBack);

        getContentPane().add(container);
		getContentPane().setBackground(Color.cyan);
        setBounds(200, 200, 400, 300);
        setResizable(true);
        setTitle("Login Page");
        setVisible(true);
      
    
   try
     {
     Class.forName("com.mysql.jdbc.Driver");
	  cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");
        st=cn.createStatement();
      }
    catch(Exception e)
    {
      JOptionPane.showMessageDialog(this,"Error is"+e);
    }
addWindowListener(new WindowAdapter() 
 {
   public void windowClosing(WindowEvent e) 
    {
     dispose();
     }
 });  
  }
  public void actionPerformed(ActionEvent ae)
  {
    try
    {
if(ae.getSource()==cmdBack)
{
//new HomePage();
System.exit(0);
dispose();

}
       if(ae.getSource()==cmdReset)
       {
         t1.setText("");
         t2.setText("");
         t1.requestFocus();
       }
      if(ae.getSource()==cmdLogin)
        {
           //if((t1.getText().trim().length()<1)||(t1.getText().trim().length()>10))
		    if((t1.getText().trim().length()>7))
         {
       JOptionPane.showMessageDialog(this," plz.....Enter username less than 7");
         return;   
         }
    //if((t2.getText().trim().length()<1)||(t2.getText().trim().length()>10))
	if((t2.getText().trim().length()>7))
     {
       JOptionPane.showMessageDialog(this,"plz....Enter password less than 7");
         return;
      }
     rs=st.executeQuery("Select PASSWORD from pass where USERNAME='"+t1.getText()+"'");
      if(rs.next())
      {
        if(rs.getString(1).equals(t2.getText()))
          { 
          JOptionPane.showMessageDialog(this,"Wel-come To Mobile Management System");
           new Home();
              dispose();
           }
           else
         JOptionPane.showMessageDialog(this,"Invalid Password");
      }
      else
       JOptionPane.showMessageDialog(this,"Invalid Uname");
      }    
   
  }
  catch(Exception e)
    {
     JOptionPane.showMessageDialog(this,"Error is "+e);
    }
  }
  public static void main(String args[])
  {
   new Login();
   }
}