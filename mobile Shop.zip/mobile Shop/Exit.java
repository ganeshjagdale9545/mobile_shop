import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.net.*;
import java.applet.*;
									
class Exit extends JFrame implements ActionListener
{
	JLabel l;
	JButton b1,b2;
	AudioClip aclip,aclip1;
	Container c = getContentPane();
	public Exit()
	{
		super("Exit...!");
                c.setBackground(Color.pink);
	  l=new JLabel("Do  You  Want  To  Exit  From  Mobile  Billing  System....?");
	  l.setForeground(Color.red);
	  l.setFont(new Font("Times New Roman",Font.BOLD,20));
	  
	  b1=new JButton("YES");
	  b1.setBackground(Color.cyan);
	  b1.setForeground(Color.blue);	
      b2=new JButton("NO");
	  b2.setBackground(Color.cyan);
	  b2.setForeground(Color.blue);	
	  
	      try
		{
		   aclip=Applet.newAudioClip(new URL("file:CASTANET.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
	    }
		
	      try
		{
		   aclip1=Applet.newAudioClip(new URL("file:GLUG.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		
	 	 
	  setVisible(true);
	  setSize(550,275);
	  setLayout(null);
	  setLocation(250,200);
	  
	  bound();
	  add();
	}
	void bound()
	{
		l.setBounds(10,50,700,20);
		b1.setBounds(70,100,300,25);
		b2.setBounds(70,125,300,25);
		
	}
	void add()
	{
		add(l);
	    add(b1);
	    add(b2);
	    b1.setMnemonic('y');
	    b1.setToolTipText("Press 'Alt+y'To Exit  From  The System");
	    b2.setMnemonic('n');
	    b2.setToolTipText("Press 'Alt+n'To Cancel exit");
	    addEvent();
	    
	}
	
	void addEvent()
	{
		b1.addActionListener(this);
		b2.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton b=(JButton)ae.getSource();
		if(b==b2)
		{
			aclip.play();
			setVisible(false);
		}
		
		if(b==b1)
		{ 
		   aclip1.play();
		   new Thanks();
		   setVisible(false);
	    }
	  }
          public static void main(String arg[])
	     {
		   new Exit();
	     }
	
}
