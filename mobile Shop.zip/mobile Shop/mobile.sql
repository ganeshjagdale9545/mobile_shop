/*
SQLyog Community Edition- MySQL GUI v8.0 
MySQL - 5.0.27-community-nt : Database - mobile
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`mobile` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mobile`;

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `cust_no` int(11) NOT NULL auto_increment,
  `cust_name` text,
  `cust_add` text,
  `cust_mo` text,
  `cust_date` text,
  `cust_totl` text,
  `cust_bill` text,
  `paid` text,
  PRIMARY KEY  (`cust_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`cust_no`,`cust_name`,`cust_add`,`cust_mo`,`cust_date`,`cust_totl`,`cust_bill`,`paid`) values (1,'ganesh jagdale','sangamner','+919545846507',' 21/03/2019',' 15000.0','Paid','10000');

/*Table structure for table `id1` */

DROP TABLE IF EXISTS `id1`;

CREATE TABLE `id1` (
  `pid` text,
  `pn` text,
  `inp` text,
  `pp` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `id1` */

insert  into `id1`(`pid`,`pn`,`inp`,`pp`) values ('1','Samsung j5','01','15000');

/*Table structure for table `pass` */

DROP TABLE IF EXISTS `pass`;

CREATE TABLE `pass` (
  `USERNAME` text,
  `PASSWORD` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pass` */

insert  into `pass`(`USERNAME`,`PASSWORD`) values ('user','12345');

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `pid` int(11) NOT NULL auto_increment,
  `pn` text,
  `pp` text,
  `noi` text,
  PRIMARY KEY  (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `product` */

insert  into `product`(`pid`,`pn`,`pp`,`noi`) values (1,'Samsung j5','15000','19'),(2,'samsung j2','8000','20'),(3,'Redmi Note 4','9999','20'),(4,'Redmi Note 5','11999','20'),(5,'Redmi Note 5 pro','11999','20'),(6,'Redmi Note A1','11999','20'),(7,'Vivo v11','21999','20'),(8,'Vivo v15','25999','20');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
