import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.net.*;
import java.applet.*;
									
class IsDelete extends JFrame implements ActionListener
{
	JLabel l;
	JButton b1,b2;
	AudioClip aclip;
	Container c = getContentPane();
	public IsDelete()
	{
		super("Confirm delete...!");
		c.setBackground(Color.green);
	  l=new JLabel("Do  You  Want  To  Delete  All  Record ....?");
	  l.setForeground(Color.red);
	 
	  l.setFont(new Font("Times New Roman",Font.BOLD,20));
	  
	  b1=new JButton("YES");
	  b1.setBackground(Color.cyan);
	  b1.setForeground(Color.blue);	
      b2=new JButton("NO");
	  b2.setBackground(Color.cyan);
	  b2.setForeground(Color.blue);	
	  
	      try
		{
		   aclip=Applet.newAudioClip(new URL("file:ARROW.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
	    }
		
	      
      setVisible(true);
	  setSize(500,250);
	  setLayout(null);
	  setLocation(250,200);
	  
	  bound();
	  add();
	}
	void bound()
	{
		l.setBounds(50,50,700,20);
		b1.setBounds(70,100,300,25);
		b2.setBounds(70,125,300,25);
		
	}
	void add()
	{
		add(l);
	    add(b1);
	    add(b2);
	    b1.setMnemonic('y');
	    b1.setToolTipText("Press 'Alt+y'To Delete The Record");
	    b2.setMnemonic('n');
	    b2.setToolTipText("Press 'Alt+n'To Cancel Delete");
	     
	    addEvent();
	}
	
	void addEvent()
	{
		b1.addActionListener(this);
		b2.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton b=(JButton)ae.getSource();
		if(b==b2)
		{
			aclip.play();
			
		    new Home();
		 setVisible(false);
		}
		
		if(b==b1)
		{ 
		   aclip.play();
		   
		   new AllDelete();
		   setVisible(false);
	    }
	  }
          public static void main(String arg[])
	     {
		   new IsDelete();
	     }
	
}