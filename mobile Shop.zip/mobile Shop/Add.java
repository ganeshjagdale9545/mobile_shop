import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;	
import java.applet.*;
import java.net.*;										
class Add extends JFrame implements ActionListener
{
	JLabel pidl,pnl,ppl,noil;
	JButton b1,b2,b3,b4,b5,b6;
	AudioClip aclip,aclip1;
        JTextField pid,pn,pp,noi;
	Container c = getContentPane();
	Connection con;
    PreparedStatement ps;
    Statement stmt;
Statement st;
    ResultSet rs;
	public Add()
	{
		super("ADD...!");
		c.setBackground(Color.green);
pidl=new JLabel("Product ID :");
pnl=new JLabel("Product Name :");
ppl=new JLabel("Product Price :");
noil=new JLabel("Number of item :");
	    b1=new JButton("ADD");
	    b1.setBackground(Color.cyan);
	    b1.setForeground(Color.blue);	
        b2=new JButton("Exit");
	    b2.setBackground(Color.cyan);
	    b2.setForeground(Color.blue);	
	  b3=new JButton("Back");
	    b3.setBackground(Color.cyan);
	    b3.setForeground(Color.blue);
           b4=new JButton("Update");
	    b4.setBackground(Color.cyan);
	    b4.setForeground(Color.blue);
           b5=new JButton("Delete");
	    b5.setBackground(Color.cyan);
	    b5.setForeground(Color.blue);
           b6=new JButton("Search");
	    b6.setBackground(Color.cyan);
	    b6.setForeground(Color.blue);
pid=new JTextField("");
pn=new JTextField("");
pp=new JTextField("");
noi=new JTextField("");
	       try
		{
		   aclip=Applet.newAudioClip(new URL("file:CASTANET.wav"));
		}  
	       catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		try
		{
		    aclip1=Applet.newAudioClip(new URL("file:GLUG.wav"));
	    }
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
	 	 
	  setVisible(true);
	  setSize(1000,500);
	  setLayout(null);
	  setLocation(20,25);
	  
	  bound();
	  add();
	}
	void bound()
	{
		pidl.setBounds(40,50,100,30);
                pid.setBounds(170,50,250,30);
                b6.setBounds(430,50,80,30);
                 pnl.setBounds(40,90,100,30);
                pn.setBounds(170,90,250,30);
                ppl.setBounds(40,130,100,30);
                pp.setBounds(170,130,250,30);
                noil.setBounds(40,170,100,30);
                noi.setBounds(170,170,250,30);
		b1.setBounds(40,210,80,30);
                b4.setBounds(130,210,80,30);
                b5.setBounds(220,210,80,30);
                b1.setBounds(40,210,80,30);
		b3.setBounds(310,210,80,30);
                b2.setBounds(400,210,80,30);
	}
	void add()
	{
add(noil);
add(b4);
add(b5);
add(noi);
add(b6);	
	add(pidl);
add(pnl);
add(ppl);
add(pid);
add(pn);
add(pp);
	    add(b1);
	    add(b2);
             add(b3);
             
	    b1.setMnemonic('c');
	    b1.setToolTipText("Click 'Alt+c' To Continue");
	    b2.setMnemonic('e');
	    b2.setToolTipText("Press 'Alt+e'To Exit  From  The System");
	   
	    addEvent();
	}
	
	void addEvent()
	{
		b1.addActionListener(this);
		b2.addActionListener(this);
                b3.addActionListener(this);
                b4.addActionListener(this);
                b5.addActionListener(this);
                b6.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton b=(JButton)ae.getSource();
try{
 Class.forName("com.mysql.jdbc.Driver");
	                                  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");
}
catch(Exception e)
			                   {
				                    aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
			                     }	
	if(b==b3)
		{   
		    aclip.play();
			
		    new Home();
		    setVisible(false);
		 }
		
		if(b==b2)
		{ 
		   aclip1.play();
		  
		   new Exit();
		    
	    }
           if(b==b1)
		{ 
 try
			                        {
		   aclip1.play();
		 
			 	                    


stmt=con.createStatement();
				                      rs=stmt.executeQuery("select max(pid) from product");
				                      rs.next();
				                      int id = rs.getInt(1)+1;
				   
                                               
			                         ps=con.prepareStatement("insert into product(pid,pn,pp,noi)values(?,?,?,?)");
				                   
    				                 ps.setInt(1,id);
				                     ps.setString(2,pn.getText());
				                     ps.setString(3,pp.getText());
				                     ps.setString(4,noi.getText());
				                     ps.executeUpdate();
JOptionPane.showMessageDialog((Component) null,"Congradulation...Your  Record  Saved  Succsessfully  To  The  Database.","Congradulation",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
			                       }
			                catch(Exception e)
			                   {
				                    aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
			                     }
   
	    }
if(b==b4)
		{ 
		try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");  
String query = "update product set pn = ?,pp=?,noi=? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);
preparedStmt.setString(4,pid.getText());
				                     preparedStmt.setString(1,pn.getText());
				                     preparedStmt.setString(2,pp.getText());
				                     preparedStmt.setString(3,noi.getText());
preparedStmt.executeUpdate();
JOptionPane.showMessageDialog((Component) null,"Congradulation...Your  Record  Saved  Succsessfully  To  The  Database.","Congradulation",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}   

		    
	    }
if(b==b5)
		{ 
		  try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root"); 


PreparedStatement st2 = con.prepareStatement("DELETE FROM product WHERE pid = ?");
st2.setString(1,pid.getText());
st2.executeUpdate(); 
pn.setText("");
pid.setText("");
				pp.setText("");
noi.setText("");
JOptionPane.showMessageDialog((Component) null,"Congradulation...Your  Record  Deleted  Succsessfully.","Congradulation",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		    
	    }
if(b==b6)
		{ 
		try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+pid.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
pn.setText(rs.getString("pn"));
				pp.setText(rs.getString("pp"));
noi.setText(rs.getString("noi"));
}
else{
pn.setText("");
				pp.setText("");
noi.setText("");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		    
	    }
	 }
          public static void main(String arg[])
	     {
		   new Add();
	     }

}