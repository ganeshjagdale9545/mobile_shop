import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.applet.*;
import java.util.Date.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

class Homeb extends JFrame implements ActionListener
{
private static final String FILENAME = "filename.txt";
	JButton sav,stock,opn,totl,ext,clr,cdate,srchid,srchnm,srchd,f1,f2,f3,f4,f5,f6,f7,f8,next,pre,up,del;
	JLabel mobile,sri,pho,cname,cadd,cpho,mname,nom,pri,cidl,pidl;
	JTextField cid,c1,c2,c3,c4,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15,m16,m17,m18,m19,m20,m21,m22,m23,m24,m25,m26,id1,id2,id3,id4,id5,id6,id7,id8;
    JComboBox jk2;
   Statement st,st1;
    Connection con;
    PreparedStatement ps;
    Statement stmt;
    ResultSet rs,rss;
    AudioClip aclip,aclip1,aclip2;
    
    
    JMenuBar mb;
    JMenu file,help,edit,delete;
    JMenuItem New,save,add,open,exit,print,change,information,d1,d2;
	
	Container c = getContentPane();
     public Homeb(String ll)	
  {
  	
			
     super("Mobile  Billing  System...!");
java.util.Date  myDate = new java.util.Date ();
String today= new SimpleDateFormat("dd/MM/yyyy").format(myDate);
       // c.setBackground(Color.green);
       String st1=" ";
          try
		{
		   aclip=Applet.newAudioClip(new URL("file:ARROW.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
	    }
		
	      try
		{
		   aclip1=Applet.newAudioClip(new URL("file:GLUG.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		
		try
		{
		   aclip2=Applet.newAudioClip(new URL("file:CASTANET.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		
		String bill[] = {"**Bill**","Paid","Remaining"};
		jk2=new JComboBox(bill);
	
	 clr=new JButton("Clear");
stock=new JButton("Stock");
     ext=new JButton("exit");
	 sav=new JButton("Save");
next=new JButton("Next");
pre=new JButton("Previous");
	 opn=new JButton("Open");
up=new JButton("Update");
del=new JButton("Delete");
f1=new JButton("Fill");
f2=new JButton("Fill");
f3=new JButton("Fill");
f4=new JButton("Fill");
f5=new JButton("Fill");
f6=new JButton("Fill");
f7=new JButton("Fill");
f8=new JButton("Fill");
	 totl=new JButton("Total");
	 cdate=new JButton("Date");
         srchid=new JButton("Search");
srchnm=new JButton("Search");
srchd=new JButton("Search");
	 
	 mobile=new JLabel("S.S mobile .",new ImageIcon("fly.gif"),JLabel.CENTER);
     mobile.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	 pho=new JLabel("(02422)246596",new ImageIcon("phone.gif"),JLabel.CENTER);
	 pho.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,15));
	 sri=new JLabel("Shrirampur,Shivaji Road .");
	 sri.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,15));
    
     cidl=new JLabel("Customer ID:");
     cname=new JLabel("Customer name:");
     cadd=new JLabel("Address");
     cpho=new JLabel("Mobile");
pidl=new JLabel("Product ID");
     
     mname=new JLabel("Mobile Name");
     nom=new JLabel("No. Of Item");
     pri=new JLabel("Price");
     
     cid=new JTextField("");
     c1=new JTextField(ll);
     c3=new JTextField("");
     c2=new JTextField("");
     c4=new JTextField("+91");
     m1=new JTextField();
     m2=new JTextField("0");
     m3=new JTextField("0");
     m4=new JTextField();
     m5=new JTextField("0");
     m6=new JTextField("0");
     m7=new JTextField();
     m8=new JTextField("0");
     m9=new JTextField("0");
     m10=new JTextField();
     m11=new JTextField("0");
     m12=new JTextField("0");
     m13=new JTextField();
     m14=new JTextField("0");
     m15=new JTextField("0");
     m16=new JTextField();
     m17=new JTextField("0");
     m18=new JTextField("0");
     m19=new JTextField();
     m20=new JTextField("0");
     m21=new JTextField("0");
     m22=new JTextField();
     m23=new JTextField("0");
     m24=new JTextField("0");
     m25=new JTextField();
m26=new JTextField("0");
    cid=new JTextField("");
id1=new JTextField("");
id2=new JTextField("");
id3=new JTextField("");
id4=new JTextField("");
id5=new JTextField("");
id6=new JTextField("");
id7=new JTextField("");
id8=new JTextField("");
     c1.setBackground(Color.yellow);
     c2.setBackground(Color.yellow);
     c3.setBackground(Color.yellow);
     c4.setBackground(Color.yellow);
     jk2.setBackground(Color.cyan);
     jk2.setForeground(Color.blue);
    
    sav.setBackground(Color.cyan);
    opn.setBackground(Color.cyan);
    ext.setBackground(Color.cyan);
    clr.setBackground(Color.cyan);
    totl.setBackground(Color.cyan);
    srchid.setBackground(Color.cyan);
srchnm.setBackground(Color.cyan);
next.setBackground(Color.cyan);
pre.setBackground(Color.cyan);
srchd.setBackground(Color.cyan);
f1.setBackground(Color.cyan);
f1.setForeground(Color.blue);
f2.setBackground(Color.cyan);
f2.setForeground(Color.blue);
f3.setBackground(Color.cyan);
f3.setForeground(Color.blue);
f4.setBackground(Color.cyan);
f4.setForeground(Color.blue);
f5.setBackground(Color.cyan);
f5.setForeground(Color.blue);
f6.setBackground(Color.cyan);
f6.setForeground(Color.blue);
f7.setBackground(Color.cyan);
f7.setForeground(Color.blue);
f8.setBackground(Color.cyan);
f8.setForeground(Color.blue);
up.setBackground(Color.cyan);
up.setForeground(Color.blue);
del.setBackground(Color.cyan);
del.setForeground(Color.blue);
    sav.setForeground(Color.blue);
	opn.setForeground(Color.blue);
	totl.setForeground(Color.blue);
	ext.setForeground(Color.blue);
    clr.setForeground(Color.blue);
srchid.setForeground(Color.blue);
srchnm.setForeground(Color.blue);
srchd.setForeground(Color.blue);
next.setForeground(Color.blue);
pre.setForeground(Color.blue);
    cdate.setForeground(Color.blue);
    cdate.setBackground(Color.white);
    	stock.setForeground(Color.blue);
    stock.setBackground(Color.cyan);
	mobile.setForeground(Color.blue);
	sri.setForeground(Color.blue);
	pho.setForeground(Color.blue);
	cname.setForeground(Color.blue);
	cadd.setForeground(Color.blue);
	cpho.setForeground(Color.blue);
	
	mname.setForeground(Color.blue);
	nom.setForeground(Color.blue);
	pri.setForeground(Color.blue);
        pidl.setForeground(Color.blue);
	

		    
   m1.setBackground(Color.yellow);
	m2.setBackground(Color.yellow);
    m3.setBackground(Color.yellow);
	m4.setBackground(Color.yellow);
	m5.setBackground(Color.yellow);
	m6.setBackground(Color.yellow);
	m7.setBackground(Color.yellow);
	m8.setBackground(Color.yellow);
	m9.setBackground(Color.yellow);
	m10.setBackground(Color.yellow);
	m11.setBackground(Color.yellow);
	m12.setBackground(Color.yellow);
	m13.setBackground(Color.yellow);
	m14.setBackground(Color.yellow);
	m15.setBackground(Color.yellow);
	m16.setBackground(Color.yellow);
	m17.setBackground(Color.yellow);
	m18.setBackground(Color.yellow);
	m19.setBackground(Color.yellow);
	m20.setBackground(Color.yellow);
	m21.setBackground(Color.yellow);
	m22.setBackground(Color.yellow);
	m23.setBackground(Color.yellow);
	m24.setBackground(Color.yellow);
	m25.setBackground(Color.yellow);
m26.setBackground(Color.yellow);
cid.setBackground(Color.yellow);
id1.setBackground(Color.yellow);
id2.setBackground(Color.yellow);
id3.setBackground(Color.yellow);
id4.setBackground(Color.yellow);
id5.setBackground(Color.yellow);
id6.setBackground(Color.yellow);
id7.setBackground(Color.yellow);
id8.setBackground(Color.yellow);
	c3.setText(""+today);
	

	//MENUBAR IS STARTED

        mb=new JMenuBar();
        setJMenuBar(mb);
        mb.setBackground(new Color(170,80,90));

        file=new JMenu("File");
        help=new JMenu("Help");
        edit=new JMenu("Edit");
        delete=new JMenu("Delete");
        
       file.setFont(new Font("Georgia",Font.BOLD,12));
       file.setForeground(Color.green);
       help.setFont(new Font("Georgia",Font.BOLD,12));
       help.setForeground(Color.green);
       
       edit.setFont(new Font("Georgia",Font.BOLD,12));
       edit.setForeground(Color.green);
       
       New=new JMenuItem("New",new ImageIcon("next.gif"));
       add=new JMenuItem("Add Product",new ImageIcon("folderopen.gif"));
       save=new JMenuItem("Save",new ImageIcon("folder.gif"));
       open=new JMenuItem("Open",new ImageIcon("folderopen.gif"));
       print=new JMenuItem("Print",new ImageIcon("printer.gif"));
       exit=new JMenuItem("Exit",new ImageIcon("close.gif"));
       
       change=new JMenuItem("Change Password",new ImageIcon("help.gif"));
        information=new JMenuItem("Information",new ImageIcon("help.gif"));
       d1=new JMenuItem("Delete Perticular Record",new ImageIcon("remove.gif"));
 //      d2=new JMenuItem("Delete All Records ",new ImageIcon("remove.gif"));
     
     //  file.add(New);
       //New.setFont(new Font("Georgia",Font.BOLD,12));
/*file.add(save);
       save.setFont(new Font("Georgia",Font.BOLD,12));
       file.add(add);
       add.setFont(new Font("Georgia",Font.BOLD,12));
       file.add(open);
       open.setFont(new Font("Georgia",Font.BOLD,12));
       file.add(exit);
       exit.setFont(new Font("Georgia",Font.BOLD,12));*/
       file.add(print);
       print.setFont(new Font("Georgia",Font.BOLD,12));
      /* file.add(change);
       change.setFont(new Font("Georgia",Font.BOLD,12));
       edit.add(delete);
       delete.setFont(new Font("Georgia",Font.BOLD,12));
       delete.add(d1);
       d1.setFont(new Font("Georgia",Font.BOLD,12));*/
    //   delete.add(d2);
    //   d2.setFont(new Font("Georgia",Font.BOLD,12));
       
       
       help.add(information);
       information.setFont(new Font("Georgia",Font.BOLD,12));
       
       mb.add(file);
       //mb.add(edit);
       mb.add(help);
       
       open.addActionListener(new ActionListener()
                               {
                                public void actionPerformed(ActionEvent ae)
                                 {
                                 	aclip2.play();
                                 	
                                 	new OpenRecord();
                                 	setVisible(false);
                                 }
                               }
                              );
       add.addActionListener(new ActionListener()
                               {
                                public void actionPerformed(ActionEvent ae)
                                 {
                                 	aclip2.play();
                                 	
                                 	new Add();
                                 	setVisible(false);
                                 }
                               }
                              );
       d1.addActionListener(new ActionListener()
                               {
                                public void actionPerformed(ActionEvent ae)
                                 {
                                 	aclip.play();
                                 	new Display();
                                        
                                 
                                 }
                               }
                              );
                
     /*   d2.addActionListener(new ActionListener()
                               {
                                public void actionPerformed(ActionEvent ae)
                                 {
                                 	aclip.play();
                                 	new IsDelete();
                                 }
                               }
                              );  */
      New.addActionListener(new ActionListener()
                             {    public void actionPerformed(ActionEvent ae)
                                 {      
                                        aclip.play();
                        java.util.Date  myDate = new java.util.Date ();
String today= new SimpleDateFormat("dd/MM/yyyy").format(myDate);
             c2.setEnabled(true);
             c3.setEnabled(true);
              c1.setEnabled(true);
              c4.setEnabled(true);
              m25.setEnabled(true);
        	c3.setText(""+today);
id1.setText("");
id2.setText("");
id3.setText("");
id4.setText("");
id5.setText("");
id6.setText("");
id7.setText("");
id8.setText("");
                        c1.setText("");
                        c2.setText("");
                        c4.setText("+91");
			m1.setText("");
			m2.setText("0");
                        m3.setText("0");
			m4.setText("");
			m5.setText("0");
                        m6.setText("0");
			m7.setText("");
			m8.setText("0");
                        m9.setText("0");
			m10.setText("");
			m11.setText("0");
                        m12.setText("0");
			m13.setText("");
			m14.setText("0");
                        m15.setText("0");
			m16.setText("");
			m17.setText("0");
                        m18.setText("0");
                        m19.setText("");
			m20.setText("0");
                        m21.setText("0");
			m22.setText("");
			m23.setText("0");
                        m24.setText("0");
m26.setText("0");
			m25.setText("");
                                 }
                               }
                              );

           exit.addActionListener(new ActionListener()
                               {
                                public void actionPerformed(ActionEvent ae)
                                 {
                                 	aclip1.play();
                                 	
   	                                new Exit();
   	                                
                                 }
                               }
                              );
          change.addActionListener(new ActionListener()
                               {
                                public void actionPerformed(ActionEvent ae)
                                 {
                                 	aclip2.play();
                                 	dispose();
   	                                new ChangePassword();
   	                                
                                 }
                               }
                              );




 print.addActionListener(new ActionListener()
                               {
                                public void actionPerformed(ActionEvent ae)
                                 {     
                  String tab="\t\t";                      aclip2.play();
if(m1.getText().trim().length()>14){
tab="\t\t\t\t";
}                                    
   	                                    	try (

BufferedWriter bw = new BufferedWriter(new FileWriter(FILENAME))) {

String newLine = System.getProperty("line.separator");
 bw.write("----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
bw.newLine();
			bw.write("S.S. Mobile Shop Shivajinagar,Shrirampur\t\tTel. No:(02422)246596");
                        bw.newLine();
bw.write("Customer Name:"+c1.getText()+"\t\t\t"+"Customer Address:"+c2.getText());
bw.newLine();
bw.write("Customer Mob :"+c4.getText()+"\t\t\t"+"Date:"+c3.getText());
bw.newLine();
                        bw.write("----------------------------------------------------------------------------------------------------------------------------------------------------------------------");

bw.newLine();
bw.write("PID"+"\t"+"PNAME"+"\t\t\t\t"+"NOP"+"\t\t"+"PPRICE");
bw.newLine();
                        bw.write("----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
if(m1.getText().trim().length()>14){
tab="\t\t\t";
}
else{
tab="\t\t\t\t";
}
bw.newLine();
bw.write(id1.getText()+"\t"+m1.getText()+tab+m2.getText()+"\t\t"+m3.getText());
bw.newLine();
if(m4.getText().trim().length()>14){
tab="\t\t\t";
}
else{
tab="\t\t\t\t";
}
bw.write(id2.getText()+"\t"+m4.getText()+tab+m5.getText()+"\t\t"+m6.getText());
bw.newLine();
if(m7.getText().trim().length()>14){
tab="\t\t\t";
}
else{
tab="\t\t\t\t";
}
bw.write(id3.getText()+"\t"+m7.getText()+tab+m8.getText()+"\t\t"+m9.getText());
bw.newLine();
if(m10.getText().trim().length()>14){
tab="\t\t\t";
}
else{
tab="\t\t\t\t";
}
bw.write(id4.getText()+"\t"+m10.getText()+tab+m11.getText()+"\t\t"+m12.getText());
bw.newLine();
if(m13.getText().trim().length()>14){
tab="\t\t\t";
}
else{
tab="\t\t\t\t";
}
bw.write(id5.getText()+"\t"+m13.getText()+tab+m14.getText()+"\t\t"+m15.getText());
bw.newLine();
if(m16.getText().trim().length()>14){
tab="\t\t\t";
}
else{
tab="\t\t\t\t";
}
bw.write(id6.getText()+"\t"+m16.getText()+tab+m17.getText()+"\t\t"+m18.getText());
bw.newLine();
if(m19.getText().trim().length()>14){
tab="\t\t\t";
}
else{
tab="\t\t\t\t";
}
bw.write(id7.getText()+"\t"+m19.getText()+tab+m20.getText()+"\t\t"+m21.getText());
bw.newLine();
if(m22.getText().trim().length()>14){
tab="\t\t\t";
}
else{
tab="\t\t\t\t";
}
bw.write(id8.getText()+"\t"+m22.getText()+tab+m23.getText()+"\t\t"+m24.getText());
bw.newLine();
                        bw.write("----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
bw.newLine();
                        bw.write("\t\t\t\t\tTOTAL=\t\t"+m25.getText());
bw.newLine();
                        bw.write("BILL "+(String)jk2.getSelectedItem()+" "+m26.getText());
bw.newLine();
bw.newLine();
bw.newLine();
bw.write("Sign");
bw.newLine();
                        bw.write("----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		} catch (IOException e) {

			e.printStackTrace();

		}
              
                          new Print();        }
                               }
                              );



          
   information.addActionListener(new ActionListener()
                               {
                                public void actionPerformed(ActionEvent ae)
                                 {     
                                        aclip2.play();
                                        
   	                                    new Information();
   	                                    setVisible(false);
                                 }
                               }
                              );
                            
     save.addActionListener(new ActionListener()
                             {    public void actionPerformed(ActionEvent ae)
                                 {      
                                   if((c1.getText().length()!=0) && (c2.getText().length()!=0))
{
                try
			                        {
				
				                     Class.forName("com.mysql.jdbc.Driver");
	                                  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");


String queryCheck = "select * from customer where cust_name='"+c1.getText()+"'";
Statement st = con.createStatement();
ResultSet rs1 = st.executeQuery(queryCheck);
if(rs1.absolute(1)) {
                                    String s1="select cust_no from customer where cust_name ='"+c1.getText()+"'";
                                                      stmt=con.createStatement();
				                      rs=stmt.executeQuery(s1);
				                      rs.next();
				                      int id1 = rs.getInt(1);

                                              StringBuilder sb3 = new StringBuilder();
                                                         sb3.append(id1);
                                             
                                       String s2="id"+sb3.toString();  
//c1.setText(s2);
                                                      stmt=con.createStatement();
				                     stmt.executeUpdate("DROP TABLE "+s2+"");

   PreparedStatement st2 = con.prepareStatement("DELETE FROM customer WHERE cust_name = ?");
st2.setString(1,c1.getText());
st2.executeUpdate();

}
   
 		                          stmt=con.createStatement();
				                      rs=stmt.executeQuery("select max(cust_no) from customer");
				                      rs.next();
				                      int id = rs.getInt(1)+1;
				   
                                               
			                         ps=con.prepareStatement("insert into customer(cust_no,cust_name,cust_add,cust_mo,cust_date,cust_totl,cust_bill,paid)values(?,?,?,?,?,?,?,?)");
				                   
    				                 ps.setInt(1,id);
				                     ps.setString(2,c1.getText());
				                     ps.setString(3,c2.getText());
				                     ps.setString(4,c4.getText());
				                     ps.setString(5,c3.getText());
				                     ps.setString(6,m25.getText());
				                     ps.setString(7,(String)jk2.getSelectedItem());
                                                     ps.setString(8,m26.getText());
				                     ps.executeUpdate();
         
StringBuilder sb = new StringBuilder();
sb.append(id);
String numberAsString =  "id"+sb.toString();
            String sql = "create table" + " "+numberAsString+"(pn TEXT,inp TEXT,pp TEXT)";
            stmt.executeUpdate(sql);
int i=1;
String  dis="N";
while(i<25)
{

          
             ps=con.prepareStatement("insert into "+" "+numberAsString+"(pid,pn,inp,pp)values(?,?,?,?)");
                                        int temp;
                                        String query;
                                         
                                     if(i==1)
                                            {
                                         
                                          if(id1.getText().length()!=0)	
{      

                                        
				        rs=stmt.executeQuery("select noi from product where pid='"+id1.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m2.getText()))
{                                                ps.setString(1,id1.getText());
    				                 ps.setString(2,m1.getText());
				                     ps.setString(3,m2.getText());
				                     ps.setString(4,m3.getText());
			                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m2.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id1.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id1.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
}                                                  
}
                                     if(i==4)
                                            {
if(id2.getText().length()!=0)	
{				                     
  rs=stmt.executeQuery("select noi from product where pid='"+id2.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m5.getText()))
{
    				                 ps.setString(1,id2.getText());
    				                 ps.setString(2,m4.getText());
				                     ps.setString(3,m5.getText());
				                     ps.setString(4,m6.getText());
ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m5.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id2.getText());

				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id2.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));


}
}                                 
                                                  }
                                     if(i==7)
                                            {
if(id3.getText().length()!=0)
{	
    				               rs=stmt.executeQuery("select noi from product where pid='"+id3.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m8.getText()))
{
    				                 ps.setString(1,id3.getText());
    				                 ps.setString(2,m7.getText());
				                     ps.setString(3,m8.getText());
				                     ps.setString(4,m9.getText());
			                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m8.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id3.getText());

dis="Y";				                    
preparedStmt.executeUpdate();}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id3.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));

}
}                                 
                                                  }
                                     if(i==10)
                                            {
if(id4.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id4.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m11.getText()))
{
    				                 ps.setString(1,id4.getText());
    				                 ps.setString(2,m10.getText());
				                     ps.setString(3,m11.getText());
				                     ps.setString(4,m12.getText());
 ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m11.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id4.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}
else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id4.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));

}
}                                 
                                                  }
                                     if(i==13)
                                            {
if(id5.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id5.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m14.getText()))
{
    				                  ps.setString(1,id5.getText());
    				                 ps.setString(2,m13.getText());
				                     ps.setString(3,m14.getText());
				                     ps.setString(4,m15.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m14.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id5.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id5.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
 
                                    if(i==16)
                                            {
if(id6.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id6.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m17.getText()))
{
    				                  ps.setString(1,id6.getText());
    				                 ps.setString(2,m16.getText());
				                     ps.setString(3,m17.getText());
				                     ps.setString(4,m18.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m17.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id6.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id6.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     if(i==19)
                                            {
if(id7.getText().length()!=0)
{
    				                 rs=stmt.executeQuery("select noi from product where pid='"+id7.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m20.getText()))
{
    				                  ps.setString(1,id7.getText());
    				                 ps.setString(2,m19.getText());
				                     ps.setString(3,m20.getText());
				                     ps.setString(4,m21.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m20.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id7.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id7.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     if(i==22)
                                            {
if(id8.getText().length()!=0)
{
    				                 rs=stmt.executeQuery("select noi from product where pid='"+id8.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m23.getText()))
{
    				                  ps.setString(1,id8.getText());
    				                 ps.setString(2,m22.getText());
				                     ps.setString(3,m23.getText());
				                     ps.setString(4,m24.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m23.getText());
query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id8.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id8.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     

i=i+3;
}
//                con.close();
           







if(i==26 || dis=="Y")
{
  
             aclip2.play();
					
		                             JOptionPane.showMessageDialog((Component) null,"Congradulation...Your  Record  Saved  Succsessfully  To  The  Database.","Congradulation",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}			                       }
			                catch(Exception e)
			                   {
				                    aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
			                     }
                  }else{JOptionPane.showMessageDialog((Component) null,"INVALIED DATA","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));}
	
   	                             }
                               }
                              );     
   
     delete.addActionListener(new ActionListener()
                             {    public void actionPerformed(ActionEvent ae)
                                 {  
                                    new IsDelete();   
                                 }
                               }
                              );                         
      //MENUBAR  ENDED                                                                    
                              
        setVisible(true);
		setSize(650,650);
		setLayout(null);
		setLocation(200,35);
		bound();
		add();
		addEvent();
                run();
	}
	
	void bound()
	{  
		mobile.setBounds(130,25,175,34);
		sri.setBounds(130,56,230,20);
		pho.setBounds(325,30,250,20);
		cidl.setBounds(100,100,150,20);
                cname.setBounds(100,125,150,20);
		cdate.setBounds(100,200,100,25);
		cpho.setBounds(100,150,150,20);
		cadd.setBounds(100,175,80,20);

		mname.setBounds(165,230,155,25);
                pidl.setBounds(25,230,155,25);
		nom.setBounds(310,230,100,25);
		pri.setBounds(420,230,100,25);
		
            cid.setBounds(200,100,150,25);srchid.setBounds(360,100,75,25);
	    c1.setBounds(200,125,150,25);srchnm.setBounds(360,125,75,25);
        c2.setBounds(200,175,150,25);
        c3.setBounds(200,200,150,25);srchd.setBounds(360,200,75,25);next.setBounds(435,200,75,25);pre.setBounds(510,200,85,25);
        c4.setBounds(200,150,150,25);
       
        id1.setBounds(20,250,80,25);f1.setBounds(100,250,50,25);
id2.setBounds(20,275,80,25);f2.setBounds(100,275,50,25);
id3.setBounds(20,300,80,25);f3.setBounds(100,300,50,25);
id4.setBounds(20,325,80,25);f4.setBounds(100,325,50,25);
id5.setBounds(20,350,80,25);f5.setBounds(100,350,50,25);
id6.setBounds(20,375,80,25);f6.setBounds(100,375,50,25);
id7.setBounds(20,400,80,25);f7.setBounds(100,400,50,25);
id8.setBounds(20,425,80,25);f8.setBounds(100,425,50,25);
        m1.setBounds(150,250,155,25);
        m2.setBounds(305,250,100,25);
        m3.setBounds(405,250,150,25);
        m4.setBounds(150,275,155,25);
        m5.setBounds(305,275,100,25);	
        m6.setBounds(405,275,150,25);
        m7.setBounds(150,300,155,25);
        m8.setBounds(305,300,100,25);
        m9.setBounds(405,300,150,25);
        m10.setBounds(150,325,155,25);
        m11.setBounds(305,325,100,25);
        m12.setBounds(405,325,150,25);
        m13.setBounds(150,350,155,25);
        m14.setBounds(305,350,100,25);
        m15.setBounds(405,350,150,25);
        m16.setBounds(150,375,155,25);
        m17.setBounds(305,375,100,25);
        m18.setBounds(405,375,150,25);
        m19.setBounds(150,400,155,25);
        m20.setBounds(305,400,100,25);
        m21.setBounds(405,400,150,25);
        
        m22.setBounds(150,425,155,25);
        m23.setBounds(305,425,100,25);
        m24.setBounds(405,425,150,25);
        m25.setBounds(405,450,150,25);
m26.setBounds(405,475,150,25);

        ext.setBounds(255,550,75,25);
del.setBounds(150,510,75,25);
//               srch.setBounds(355,500,75,25);
		sav.setBounds(100,510,75,25);
		opn.setBounds(255,510,75,25);
up.setBounds(50,510,75,25);
stock.setBounds(525,510,75,25);
        totl.setBounds(305,450,100,25);
        clr.setBounds(100,550,75,25);
                
       
        jk2.setBounds(305,475,100,25);
     }
     void run()
{

try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from customer where cust_name='"+c1.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
cid.setText(rs.getString("cust_no"));
c1.setText(rs.getString("cust_name"));
				c2.setText(rs.getString("cust_add"));
c3.setText(rs.getString("cust_date"));
c4.setText(rs.getString("cust_mo"));
m25.setText(rs.getString("cust_totl"));
m26.setText(rs.getString("paid"));
jk2.setSelectedItem(rs.getString("cust_bill"));
int id11 = rs.getInt(1);

                                              StringBuilder sb3 = new StringBuilder();
                                                         sb3.append(id11);
                                             
                                       String s2="id"+sb3.toString();

			st = con.createStatement();
            rs = st.executeQuery("select * from  "+s2+"");
try
	   	 {
//rs.next();
rs.next();
id1.setText(rs.getString("pid"));
m1.setText(rs.getString("pn"));
m2.setText(rs.getString("inp"));
m3.setText(rs.getString("pp"));
rs.next();
id2.setText(rs.getString("pid"));
m4.setText(rs.getString("pn"));
m5.setText(rs.getString("inp"));
m6.setText(rs.getString("pp"));
rs.next();
id3.setText(rs.getString("pid"));
m7.setText(rs.getString("pn"));
m8.setText(rs.getString("inp"));
m9.setText(rs.getString("pp"));
rs.next();
id4.setText(rs.getString("pid"));
m10.setText(rs.getString("pn"));
m11.setText(rs.getString("inp"));
m12.setText(rs.getString("pp"));
rs.next();
id5.setText(rs.getString("pid"));
m13.setText(rs.getString("pn"));
m14.setText(rs.getString("inp"));
m15.setText(rs.getString("pp"));
rs.next();
id6.setText(rs.getString("pid"));
m16.setText(rs.getString("pn"));
m17.setText(rs.getString("inp"));
m18.setText(rs.getString("pp"));
rs.next();
id7.setText(rs.getString("pid"));
m19.setText(rs.getString("pn"));
m20.setText(rs.getString("inp"));
m21.setText(rs.getString("pp"));
rs.next();
id8.setText(rs.getString("pid"));
m22.setText(rs.getString("pn"));
m23.setText(rs.getString("inp"));
m24.setText(rs.getString("pp"));
rs.next();
}
 catch(SQLException sqle)
		{
//JOptionPane.showMessageDialog((Component) null,"DONE","OK",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
		}
}
else{
c1.setText("");
				c2.setText("");
c3.setText("");
c4.setText("");
m25.setText("");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		    
			



}
	void add()
	{
add(up);
add(del);	   
 add(mobile);
//add(stock);
		add(sri);
		add(pho);
		add(cname);
		add(cadd);
		add(cpho);
		
//add(next);
add(f1);
add(f2);
add(f3);
add(f4);
add(f5);
add(f6);
add(f7);
add(f8);

//add(pre);
		add(mname);
		add(nom);
		add(pri);
		
		//add(ext);
		//add(sav);
		//add(opn);
		add(totl);
		//add(clr);
		add(cdate);
add(pidl);
                //add(srchid);
//add(srchnm);
//add(srchd);
add(cidl);
add(cid);
add(id1);
add(id2);
add(id3);
add(id4);
add(id5);
add(id6);
add(id7);
add(id8);
		
		add(c1);
		add(c2);
		 add(c3);
		add(c4);
	
		add(m4);
		add(m5);
		add(m6);
		add(m7);
		add(m8);
		add(m9);
		add(m10);
		add(m11);
		add(m12);
		add(m13);
		add(m14);
		add(m15);
		add(m16);
		add(m17);
		add(m18);
		add(m19);
		add(m20);
		add(m21);
		add(m22);
		add(m23);
		add(m24);
		add(m1);
		add(m2);
		add(m3);
		add(m25);
		add(m26);
		
		add(jk2);
		
	   // sav.setMnemonic('s');
	    //sav.setToolTipText("Press 'Alt+s'To Save Your Records");
	    //opn.setMnemonic('o');
	    //opn.setToolTipText("Press 'Alt+o'To Open Your Records");
	    //totl.setMnemonic('t');
	    //totl.setToolTipText("Press 'Alt+t'To Get Total");
	    //ext.setMnemonic('e');
	    //ext.setToolTipText("Press 'Alt+e'To Exit  From  The System");
	    //clr.setMnemonic('c');
	    //clr.setToolTipText("Press 'Alt+c'To Clear The TextField");
	
	}
	
	 public void addEvent()
      {
      	opn.addActionListener(this);
     	sav.addActionListener(this);
     	ext.addActionListener(this);
     	clr.addActionListener(this);
     	totl.addActionListener(this);
        cdate.addActionListener(this);
        srchid.addActionListener(this);
srchnm.addActionListener(this);
srchd.addActionListener(this);
f1.addActionListener(this);
f2.addActionListener(this);
f3.addActionListener(this);
f4.addActionListener(this);
f5.addActionListener(this);
f6.addActionListener(this);
f7.addActionListener(this);
f8.addActionListener(this);
next.addActionListener(this);
pre.addActionListener(this);
up.addActionListener(this);
del.addActionListener(this);
stock.addActionListener(this);
      }	
     
     	public void actionPerformed(ActionEvent ae)
	{
		JButton b=(JButton)ae.getSource();


if(b==up)
        {
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from id"+cid.getText();
			st = con.createStatement();
            rs = st.executeQuery(query);


} 
 catch(Exception e)
			                   {
				                    aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
			                     }  
try
{
int inp;
String pn;
String query;
int inpp;
PreparedStatement preparedStmt;
rs.next();
inp=rs.getInt("inp");
 pn=rs.getString("pn");
			st1 = con.createStatement();
            rss = st1.executeQuery("select * from product where pn='"+pn+"'");
rss.next();
inpp=rss.getInt("noi");
inpp=inpp+inp;

 query = "update product set noi='"+inpp+"' where pn='"+pn+"'";
       preparedStmt = con.prepareStatement(query);
				                     			                     
preparedStmt.executeUpdate();

rs.next();
inp=rs.getInt("inp");
 pn=rs.getString("pn");

			st1 = con.createStatement();
            rss = st1.executeQuery("select * from product where pn='"+pn+"'");
rss.next();
 inpp=rss.getInt("noi");
inpp=inpp+inp;

 query = "update product set noi='"+inpp+"' where pn='"+pn+"'";
       preparedStmt = con.prepareStatement(query);
				                     			                     
preparedStmt.executeUpdate();

rs.next();
inp=rs.getInt("inp");
 pn=rs.getString("pn");

			st1 = con.createStatement();
            rss = st1.executeQuery("select * from product where pn='"+pn+"'");
rss.next();
 inpp=rss.getInt("noi");
inpp=inpp+inp;
 query = "update product set noi='"+inpp+"' where pn='"+pn+"'";
       preparedStmt = con.prepareStatement(query);
				                     			                     
preparedStmt.executeUpdate();

rs.next();
inp=rs.getInt("inp");
 pn=rs.getString("pn");

			st1 = con.createStatement();
            rss = st1.executeQuery("select * from product where pn='"+pn+"'");
rss.next();
 inpp=rss.getInt("noi");
inpp=inpp+inp;

 query = "update product set noi='"+inpp+"' where pn='"+pn+"'";
       preparedStmt = con.prepareStatement(query);
				                     			                     
preparedStmt.executeUpdate();

rs.next();
inp=rs.getInt("inp");
 pn=rs.getString("pn");

			st1 = con.createStatement();
            rss = st1.executeQuery("select * from product where pn='"+pn+"'");
rss.next();
 inpp=rss.getInt("noi");
inpp=inpp+inp;

 query = "update product set noi='"+inpp+"' where pn='"+pn+"'";
       preparedStmt = con.prepareStatement(query);
				                     			                     
preparedStmt.executeUpdate();


rs.next();
inp=rs.getInt("inp");
 pn=rs.getString("pn");

			st1 = con.createStatement();
            rss = st1.executeQuery("select * from product where pn='"+pn+"'");
rss.next();
 inpp=rss.getInt("noi");
inpp=inpp+inp;

 query = "update product set noi='"+inpp+"' where pn='"+pn+"'";
       preparedStmt = con.prepareStatement(query);
				                     			                     
preparedStmt.executeUpdate();


rs.next();
inp=rs.getInt("inp");
 pn=rs.getString("pn");

			st1 = con.createStatement();
            rss = st1.executeQuery("select * from product where pn='"+pn+"'");
rss.next();
 inpp=rss.getInt("noi");
inpp=inpp+inp;

 query = "update product set noi='"+inpp+"' where pn='"+pn+"'";
       preparedStmt = con.prepareStatement(query);
				                     			                     
preparedStmt.executeUpdate();

rs.next();
inp=rs.getInt("inp");
 pn=rs.getString("pn");

			st1 = con.createStatement();
            rss = st1.executeQuery("select * from product where pn='"+pn+"'");
rss.next();
inpp=rss.getInt("noi");
inpp=inpp+inp;

 query = "update product set noi='"+inpp+"' where pn='"+pn+"'";
       preparedStmt = con.prepareStatement(query);
				                     			                     
preparedStmt.executeUpdate();

}
 catch(SQLException sqle)
		{
			
		}
try{

                                             
                                       String s2="id"+cid.getText();  

                                                      stmt=con.createStatement();
				                     stmt.executeUpdate("DROP TABLE "+s2+"");
}
catch(SQLException sqle)
		{
			
		}
try{



       ps = con.prepareStatement("update customer set cust_name=?,cust_add=?,cust_mo=?,cust_date=?,cust_totl=?,cust_bill=?,paid=? where cust_no=?");	      
ps.setString(8,cid.getText());
				                     ps.setString(1,c1.getText());
				                     ps.setString(2,c2.getText());
				                     ps.setString(3,c4.getText());
				                     ps.setString(4,c3.getText());
				                     ps.setString(5,m25.getText());
				                     ps.setString(6,(String)jk2.getSelectedItem());
               	                                      ps.setString(7,m26.getText());		                     
ps.executeUpdate();
 
           String numberAsString="id"+cid.getText();

            stmt.executeUpdate("create table "+numberAsString+"(pid TEXT,pn TEXT,inp TEXT,pp TEXT)");
int i=1;
String  dis="N";
while(i<25)
{

             ps=con.prepareStatement("insert into "+" "+numberAsString+"(pid,pn,inp,pp)values(?,?,?,?)");
                                        int temp;
                                        String query;
                                         
                                     if(i==1)
                                            {
                                         
                                          if(id1.getText().length()!=0)	
{      

                                        
				        rs=stmt.executeQuery("select noi from product where pid='"+id1.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m2.getText()))
{                                                ps.setString(1,id1.getText());
    				                 ps.setString(2,m1.getText());
				                     ps.setString(3,m2.getText());
				                     ps.setString(4,m3.getText());
			                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m2.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id1.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id1.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
}                                                  
}
                                     if(i==4)
                                            {
if(id2.getText().length()!=0)	
{				                     
  rs=stmt.executeQuery("select noi from product where pid='"+id2.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m5.getText()))
{
    				                 ps.setString(1,id2.getText());
    				                 ps.setString(2,m4.getText());
				                     ps.setString(3,m5.getText());
				                     ps.setString(4,m6.getText());
ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m5.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id2.getText());

				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id2.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));


}
}                                 
                                                  }
                                     if(i==7)
                                            {
if(id3.getText().length()!=0)
{	
    				               rs=stmt.executeQuery("select noi from product where pid='"+id3.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m8.getText()))
{
    				                 ps.setString(1,id3.getText());
    				                 ps.setString(2,m7.getText());
				                     ps.setString(3,m8.getText());
				                     ps.setString(4,m9.getText());
			                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m8.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id3.getText());

dis="Y";				                    
preparedStmt.executeUpdate();}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id3.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));

}
}                                 
                                                  }
                                     if(i==10)
                                            {
if(id4.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id4.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m11.getText()))
{
    				                 ps.setString(1,id4.getText());
    				                 ps.setString(2,m10.getText());
				                     ps.setString(3,m11.getText());
				                     ps.setString(4,m12.getText());
 ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m11.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id4.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}
else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id4.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));

}
}                                 
                                                  }
                                     if(i==13)
                                            {
if(id5.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id5.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m14.getText()))
{
    				                  ps.setString(1,id5.getText());
    				                 ps.setString(2,m13.getText());
				                     ps.setString(3,m14.getText());
				                     ps.setString(4,m15.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m14.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id5.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id5.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
 
                                    if(i==16)
                                            {
if(id6.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id6.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m17.getText()))
{
    				                  ps.setString(1,id6.getText());
    				                 ps.setString(2,m16.getText());
				                     ps.setString(3,m17.getText());
				                     ps.setString(4,m18.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m17.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id6.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id6.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     if(i==19)
                                            {
if(id7.getText().length()!=0)
{
    				                 rs=stmt.executeQuery("select noi from product where pid='"+id7.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m20.getText()))
{
    				                  ps.setString(1,id7.getText());
    				                 ps.setString(2,m19.getText());
				                     ps.setString(3,m20.getText());
				                     ps.setString(4,m21.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m20.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id7.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id7.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     if(i==22)
                                            {
if(id8.getText().length()!=0)
{
    				                 rs=stmt.executeQuery("select noi from product where pid='"+id8.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m23.getText()))
{
    				                  ps.setString(1,id8.getText());
    				                 ps.setString(2,m22.getText());
				                     ps.setString(3,m23.getText());
				                     ps.setString(4,m24.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m23.getText());
query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id8.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id8.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     

i=i+3;
}
//                con.close();
           







if(i==26 || dis=="Y")
{
  
             aclip2.play();
					
		                             JOptionPane.showMessageDialog((Component) null,"Congradulation...Your  Record  Saved  Succsessfully  To  The  Database.","Congradulation",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}			                       }
			                catch(Exception e)
			                   {
				                    aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
			                     }



}







if(b==f1)
        {
            
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+id1.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
m1.setText(rs.getString("pn"));
				m3.setText(rs.getString("pp"));
//noi.setText(rs.getString("noi"));
}
else{
m1.setText("");
				m3.setText("0");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		
        }	
if(b==f2)
        {
            
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+id2.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
m4.setText(rs.getString("pn"));
				m6.setText(rs.getString("pp"));
//noi.setText(rs.getString("noi"));
}
else{
m4.setText("");
				m6.setText("0");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		
        }	
if(b==f3)
        {
            
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+id3.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
m7.setText(rs.getString("pn"));
				m9.setText(rs.getString("pp"));
//noi.setText(rs.getString("noi"));
}
else{
m7.setText("");
				m9.setText("0");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		
        }	
if(b==f4)
        {
            
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+id4.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
m10.setText(rs.getString("pn"));
				m12.setText(rs.getString("pp"));
//noi.setText(rs.getString("noi"));
}
else{
m10.setText("");
				m12.setText("0");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		
        }	
if(b==f5)
        {
            
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+id5.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
m13.setText(rs.getString("pn"));
				m15.setText(rs.getString("pp"));
//noi.setText(rs.getString("noi"));
}
else{
m13.setText("");
				m15.setText("0");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		
        }	
if(b==f6)
        {
            
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+id6.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
m16.setText(rs.getString("pn"));
				m18.setText(rs.getString("pp"));
//noi.setText(rs.getString("noi"));
}
else{
m16.setText("");
				m18.setText("0");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		
        }	
if(b==f7)
        {
            
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+id7.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
m19.setText(rs.getString("pn"));
				m21.setText(rs.getString("pp"));
//noi.setText(rs.getString("noi"));
}
else{
m19.setText("");
				m21.setText("0");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		
        }	
if(b==f8)
        {
            
try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from product where pid='"+id8.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
m22.setText(rs.getString("pn"));
				m24.setText(rs.getString("pp"));
//noi.setText(rs.getString("noi"));
}
else{
m22.setText("");
				m24.setText("0");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		
        }		

if(b==cdate)
        {
            java.util.Date  myDate = new java.util.Date ();
String today= new SimpleDateFormat("dd/MM/yyyy").format(myDate);
             
        	c3.setText(""+today);
        }
		
		if(b==sav)
                {
if((c1.getText().length()!=0) && (c2.getText().length()!=0))
{
                try
			                        {
				
				                     Class.forName("com.mysql.jdbc.Driver");
	                                  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");


String queryCheck = "select * from customer where cust_name='"+c1.getText()+"'";
Statement st = con.createStatement();
ResultSet rs1 = st.executeQuery(queryCheck);
if(rs1.absolute(1)) {
                                    String s1="select cust_no from customer where cust_name ='"+c1.getText()+"'";
                                                      stmt=con.createStatement();
				                      rs=stmt.executeQuery(s1);
				                      rs.next();
				                      int id1 = rs.getInt(1);

                                              StringBuilder sb3 = new StringBuilder();
                                                         sb3.append(id1);
                                             
                                       String s2="id"+sb3.toString();  
//c1.setText(s2);
                                                      stmt=con.createStatement();
				                     stmt.executeUpdate("DROP TABLE "+s2+"");

   PreparedStatement st2 = con.prepareStatement("DELETE FROM customer WHERE cust_name = ?");
st2.setString(1,c1.getText());
st2.executeUpdate();

}
   
 		                          stmt=con.createStatement();
				                      rs=stmt.executeQuery("select max(cust_no) from customer");
				                      rs.next();
				                      int id = rs.getInt(1)+1;
				   
                                               
			                         ps=con.prepareStatement("insert into customer(cust_no,cust_name,cust_add,cust_mo,cust_date,cust_totl,cust_bill,paid)values(?,?,?,?,?,?,?,?)");
				                   
    				                 ps.setInt(1,id);
				                     ps.setString(2,c1.getText());
				                     ps.setString(3,c2.getText());
				                     ps.setString(4,c4.getText());
				                     ps.setString(5,c3.getText());
				                     ps.setString(6,m25.getText());
				                     ps.setString(7,(String)jk2.getSelectedItem());
                                                     ps.setString(8,m26.getText());
				                     ps.executeUpdate();
         
StringBuilder sb = new StringBuilder();
sb.append(id);
String numberAsString =  "id"+sb.toString();
            String sql = "create table" + " "+numberAsString+"(pid TEXT,pn TEXT,inp TEXT,pp TEXT)";
            stmt.executeUpdate(sql);
int i=1;
String  dis="N";
while(i<25)
{

            
             ps=con.prepareStatement("insert into "+" "+numberAsString+"(pid,pn,inp,pp)values(?,?,?,?)");
                                        int temp;
                                        String query;
                                         
                                     if(i==1)
                                            {
                                         
                                          if(id1.getText().length()!=0)	
{      

                                        
				        rs=stmt.executeQuery("select noi from product where pid='"+id1.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m2.getText()))
{                                                ps.setString(1,id1.getText());
    				                 ps.setString(2,m1.getText());
				                     ps.setString(3,m2.getText());
				                     ps.setString(4,m3.getText());
			                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m2.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id1.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id1.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
}                                                  
}
                                     if(i==4)
                                            {
if(id2.getText().length()!=0)	
{				                     
  rs=stmt.executeQuery("select noi from product where pid='"+id2.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m5.getText()))
{
    				                 ps.setString(1,id2.getText());
    				                 ps.setString(2,m4.getText());
				                     ps.setString(3,m5.getText());
				                     ps.setString(4,m6.getText());
ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m5.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id2.getText());

				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id2.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));


}
}                                 
                                                  }
                                     if(i==7)
                                            {
if(id3.getText().length()!=0)
{	
    				               rs=stmt.executeQuery("select noi from product where pid='"+id3.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m8.getText()))
{
    				                 ps.setString(1,id3.getText());
    				                 ps.setString(2,m7.getText());
				                     ps.setString(3,m8.getText());
				                     ps.setString(4,m9.getText());
			                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m8.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id3.getText());

dis="Y";				                    
preparedStmt.executeUpdate();}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id3.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));

}
}                                 
                                                  }
                                     if(i==10)
                                            {
if(id4.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id4.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m11.getText()))
{
    				                 ps.setString(1,id4.getText());
    				                 ps.setString(2,m10.getText());
				                     ps.setString(3,m11.getText());
				                     ps.setString(4,m12.getText());
 ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m11.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id4.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}
else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id4.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));

}
}                                 
                                                  }
                                     if(i==13)
                                            {
if(id5.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id5.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m14.getText()))
{
    				                  ps.setString(1,id5.getText());
    				                 ps.setString(2,m13.getText());
				                     ps.setString(3,m14.getText());
				                     ps.setString(4,m15.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m14.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id5.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id5.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
 
                                    if(i==16)
                                            {
if(id6.getText().length()!=0)
{
    				                rs=stmt.executeQuery("select noi from product where pid='"+id6.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m17.getText()))
{
    				                  ps.setString(1,id6.getText());
    				                 ps.setString(2,m16.getText());
				                     ps.setString(3,m17.getText());
				                     ps.setString(4,m18.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m17.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id6.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id6.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     if(i==19)
                                            {
if(id7.getText().length()!=0)
{
    				                 rs=stmt.executeQuery("select noi from product where pid='"+id7.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m20.getText()))
{
    				                  ps.setString(1,id7.getText());
    				                 ps.setString(2,m19.getText());
				                     ps.setString(3,m20.getText());
				                     ps.setString(4,m21.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m20.getText());
 query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id7.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id7.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     if(i==22)
                                            {
if(id8.getText().length()!=0)
{
    				                 rs=stmt.executeQuery("select noi from product where pid='"+id8.getText()+"'");
                                  rs.next();      
                                      
                                   if(rs.getInt(1)>=Integer.parseInt(m23.getText()))
{
    				                  ps.setString(1,id8.getText());
    				                 ps.setString(2,m22.getText());
				                     ps.setString(3,m23.getText());
				                     ps.setString(4,m24.getText());
					                     ps.executeUpdate();
temp=rs.getInt(1)-Integer.parseInt(m23.getText());
query = "update product set noi= ? where pid=?";
      PreparedStatement preparedStmt = con.prepareStatement(query);

				                     preparedStmt.setInt(1,temp);
				                     preparedStmt.setString(2,id8.getText());
				                    
preparedStmt.executeUpdate();
dis="Y";
}

else
{
i=25;
JOptionPane.showMessageDialog((Component) null,"Product ID '"+id8.getText()+"' select Out of stock.","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}                                 
}                                                  }
                                     

i=i+3;
}
//                con.close();
           







if(i==26 || dis=="Y")
{
  
             aclip2.play();
					
		                             JOptionPane.showMessageDialog((Component) null,"Congradulation...Your  Record  Saved  Succsessfully  To  The  Database.","Congradulation",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}			                       }
			                catch(Exception e)
			                   {
				                    aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
			                     }
                  }else{JOptionPane.showMessageDialog((Component) null,"INVALIED DATA","Failled",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));}     }
        
		if(b==ext)
		{
			aclip1.play();
			
		    new Exit();
		}
		if(b==clr)
		{
			aclip.play();
			 c1.setEnabled(true);
              c2.setEnabled(true);
              c3.setEnabled(true);
              c4.setEnabled(true);
              m25.setEnabled(true);
                        id1.setText("");
id2.setText("");
id3.setText("");
id4.setText("");
id5.setText("");
id6.setText("");
id7.setText("");
id8.setText("");
java.util.Date  myDate = new java.util.Date ();
String today= new SimpleDateFormat("dd/MM/yyyy").format(myDate);
             
        	c3.setText(""+today);
                        c1.setText("");
                        c2.setText("");
                        c4.setText("+91");
			m1.setText("");
			m2.setText("0");
                        m3.setText("0");
			m4.setText("");
			m5.setText("0");
                        m6.setText("0");
			m7.setText("");
			m8.setText("0");
                        m9.setText("0");
			m10.setText("");
			m11.setText("0");
                        m12.setText("0");
			m13.setText("");
			m14.setText("0");
                        m15.setText("0");
			m16.setText("");
			m17.setText("0");
                        m18.setText("0");
                        m19.setText("");
			m20.setText("0");
                        m21.setText("0");
			m22.setText("");
			m23.setText("0");
                        m24.setText("0");
                        m26.setText("0");
			m25.setText("");
			
		}
		if(b==opn)
		{    
		    aclip2.play();
		    
			new OpenRecord();
			
		}
if(b==stock)
		{    
		    aclip2.play();
		    
			new Stock();
			
		}

                if(b==srchid)
		{    
		    aclip2.play();
		    
			try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from customer where cust_no='"+cid.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
c1.setText(rs.getString("cust_name"));
				c2.setText(rs.getString("cust_add"));
c3.setText(rs.getString("cust_date"));
c4.setText(rs.getString("cust_mo"));
m25.setText(rs.getString("cust_totl"));
m26.setText(rs.getString("paid"));
jk2.setSelectedItem(rs.getString("cust_bill"));
int id11 = rs.getInt(1);

                                              StringBuilder sb3 = new StringBuilder();
                                                         sb3.append(id11);
                                             
                                       String s2="id"+sb3.toString();

			st = con.createStatement();
            rs = st.executeQuery("select * from  "+s2+"");
try
	   	 {
rs.next();
id1.setText(rs.getString("pid"));
m1.setText(rs.getString("pn"));
m2.setText(rs.getString("inp"));
m3.setText(rs.getString("pp"));
rs.next();
id2.setText(rs.getString("pid"));
m4.setText(rs.getString("pn"));
m5.setText(rs.getString("inp"));
m6.setText(rs.getString("pp"));
rs.next();
id3.setText(rs.getString("pid"));
m7.setText(rs.getString("pn"));
m8.setText(rs.getString("inp"));
m9.setText(rs.getString("pp"));
rs.next();
id4.setText(rs.getString("pid"));
m10.setText(rs.getString("pn"));
m11.setText(rs.getString("inp"));
m12.setText(rs.getString("pp"));
rs.next();
id5.setText(rs.getString("pid"));
m13.setText(rs.getString("pn"));
m14.setText(rs.getString("inp"));
m15.setText(rs.getString("pp"));
rs.next();
id6.setText(rs.getString("pid"));
m16.setText(rs.getString("pn"));
m17.setText(rs.getString("inp"));
m18.setText(rs.getString("pp"));
rs.next();
id7.setText(rs.getString("pid"));
m19.setText(rs.getString("pn"));
m20.setText(rs.getString("inp"));
m21.setText(rs.getString("pp"));
rs.next();
id8.setText(rs.getString("pid"));
m22.setText(rs.getString("pn"));
m23.setText(rs.getString("inp"));
m24.setText(rs.getString("pp"));
rs.next();
}
 catch(SQLException sqle)
		{
JOptionPane.showMessageDialog((Component) null,"DONE","OK",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
		}
}
else{
c1.setText("");
				c2.setText("");
c3.setText("");
c4.setText("");
m25.setText("");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		    
			
		}
if(b==srchnm)
		{    
		    aclip2.play();
		    
			try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from customer where cust_name='"+c1.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);
if(rs.absolute(1)) {
//rs.next();
cid.setText(rs.getString("cust_no"));
c1.setText(rs.getString("cust_name"));
				c2.setText(rs.getString("cust_add"));
c3.setText(rs.getString("cust_date"));
c4.setText(rs.getString("cust_mo"));
m25.setText(rs.getString("cust_totl"));
m26.setText(rs.getString("paid"));
jk2.setSelectedItem(rs.getString("cust_bill"));
int id11 = rs.getInt(1);

                                              StringBuilder sb3 = new StringBuilder();
                                                         sb3.append(id11);
                                             
                                       String s2="id"+sb3.toString();

			st = con.createStatement();
            rs = st.executeQuery("select * from  "+s2+"");
try
	   	 {
//rs.next();
rs.next();
id1.setText(rs.getString("pid"));
m1.setText(rs.getString("pn"));
m2.setText(rs.getString("inp"));
m3.setText(rs.getString("pp"));
rs.next();
id2.setText(rs.getString("pid"));
m4.setText(rs.getString("pn"));
m5.setText(rs.getString("inp"));
m6.setText(rs.getString("pp"));
rs.next();
id3.setText(rs.getString("pid"));
m7.setText(rs.getString("pn"));
m8.setText(rs.getString("inp"));
m9.setText(rs.getString("pp"));
rs.next();
id4.setText(rs.getString("pid"));
m10.setText(rs.getString("pn"));
m11.setText(rs.getString("inp"));
m12.setText(rs.getString("pp"));
rs.next();
id5.setText(rs.getString("pid"));
m13.setText(rs.getString("pn"));
m14.setText(rs.getString("inp"));
m15.setText(rs.getString("pp"));
rs.next();
id6.setText(rs.getString("pid"));
m16.setText(rs.getString("pn"));
m17.setText(rs.getString("inp"));
m18.setText(rs.getString("pp"));
rs.next();
id7.setText(rs.getString("pid"));
m19.setText(rs.getString("pn"));
m20.setText(rs.getString("inp"));
m21.setText(rs.getString("pp"));
rs.next();
id8.setText(rs.getString("pid"));
m22.setText(rs.getString("pn"));
m23.setText(rs.getString("inp"));
m24.setText(rs.getString("pp"));
rs.next();
}
 catch(SQLException sqle)
		{
JOptionPane.showMessageDialog((Component) null,"DONE","OK",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
		}
}
else{
c1.setText("");
				c2.setText("");
c3.setText("");
c4.setText("");
m25.setText("");
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
		} 
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
		    
			
		}
if(b==srchd)
		{

 	try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	               con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");    
			
			String query = "select * from customer where cust_date='"+c3.getText()+"'";
			st = con.createStatement();
            rs = st.executeQuery(query);

if(rs.absolute(1)) {
cid.setText(rs.getString("cust_no"));
c1.setText(rs.getString("cust_name"));
c2.setText(rs.getString("cust_add"));
c3.setText(rs.getString("cust_date"));
c4.setText(rs.getString("cust_mo"));
m25.setText(rs.getString("cust_totl"));
m26.setText(rs.getString("paid"));
jk2.setSelectedItem(rs.getString("cust_bill"));
            String s2="id"+cid.getText();
            st1 = con.createStatement();
            rss = st1.executeQuery("select * from  "+s2+"");
try
   	 {
rss.next();
id1.setText(rss.getString("pid"));
m1.setText(rss.getString("pn"));
m2.setText(rss.getString("inp"));
m3.setText(rss.getString("pp"));
rss.next();
id2.setText(rss.getString("pid"));
m4.setText(rss.getString("pn"));
m5.setText(rss.getString("inp"));
m6.setText(rss.getString("pp"));
rss.next();
id3.setText(rss.getString("pid"));
m7.setText(rss.getString("pn"));
m8.setText(rss.getString("inp"));
m9.setText(rss.getString("pp"));
rss.next();
id4.setText(rss.getString("pid"));
m10.setText(rss.getString("pn"));
m11.setText(rss.getString("inp"));
m12.setText(rss.getString("pp"));
rss.next();
id5.setText(rss.getString("pid"));
m13.setText(rss.getString("pn"));
m14.setText(rss.getString("inp"));
m15.setText(rss.getString("pp"));
rss.next();
id6.setText(rss.getString("pid"));
m16.setText(rss.getString("pn"));
m17.setText(rss.getString("inp"));
m18.setText(rss.getString("pp"));
rss.next();
id7.setText(rss.getString("pid"));
m19.setText(rss.getString("pn"));
m20.setText(rss.getString("inp"));
m21.setText(rss.getString("pp"));
rss.next();
id8.setText(rss.getString("pid"));
m22.setText(rss.getString("pn"));
m23.setText(rss.getString("inp"));
m24.setText(rss.getString("pp"));
rss.next();
}
 catch(SQLException sqle)
		{
JOptionPane.showMessageDialog((Component) null,"DONE","OK",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
		}
}
else{
JOptionPane.showMessageDialog((Component) null,"No record found","Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
}
}
 catch(Exception e)
		{
			  aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}  
}
if(b==next)
		{ 
try
	   	 {
rs.next();
cid.setText(rs.getString("cust_no"));
c1.setText(rs.getString("cust_name"));
c2.setText(rs.getString("cust_add"));
c3.setText(rs.getString("cust_date"));
c4.setText(rs.getString("cust_mo"));
m25.setText(rs.getString("cust_totl"));
m26.setText(rs.getString("paid"));
jk2.setSelectedItem(rs.getString("cust_bill"));
}
 catch(SQLException sqle)
		{
			aclip1.play();

			JOptionPane.showMessageDialog(this,"No Next Record Found....","Record",JOptionPane.INFORMATION_MESSAGE,new ImageIcon("think.gif"));
		}

try
	   	 {

 String s2="id"+cid.getText();
st1 = con.createStatement();
            rss = st1.executeQuery("select * from  "+s2+"");

rss.next();
id1.setText(rss.getString("pid"));
m1.setText(rss.getString("pn"));
m2.setText(rss.getString("inp"));
m3.setText(rss.getString("pp"));
rss.next();
id2.setText(rss.getString("pid"));
m4.setText(rss.getString("pn"));
m5.setText(rss.getString("inp"));
m6.setText(rss.getString("pp"));
rss.next();
id3.setText(rss.getString("pid"));
m7.setText(rss.getString("pn"));
m8.setText(rss.getString("inp"));
m9.setText(rss.getString("pp"));
rss.next();
id4.setText(rss.getString("pid"));
m10.setText(rss.getString("pn"));
m11.setText(rss.getString("inp"));
m12.setText(rss.getString("pp"));
rss.next();
id5.setText(rss.getString("pid"));
m13.setText(rss.getString("pn"));
m14.setText(rss.getString("inp"));
m15.setText(rss.getString("pp"));
rss.next();
id6.setText(rss.getString("pid"));
m16.setText(rss.getString("pn"));
m17.setText(rss.getString("inp"));
m18.setText(rss.getString("pp"));
rss.next();
id7.setText(rss.getString("pid"));
m19.setText(rss.getString("pn"));
m20.setText(rss.getString("inp"));
m21.setText(rss.getString("pp"));
rss.next();
id8.setText(rss.getString("pid"));
m22.setText(rss.getString("pn"));
m23.setText(rss.getString("inp"));
m24.setText(rss.getString("pp"));
rss.next();

}
 catch(SQLException sqle)
		{

		}


}
if(b==pre)
		{
try
	   	 {
rs.previous();
cid.setText(rs.getString("cust_no"));
c1.setText(rs.getString("cust_name"));
c2.setText(rs.getString("cust_add"));
c3.setText(rs.getString("cust_date"));
c4.setText(rs.getString("cust_mo"));
m25.setText(rs.getString("cust_totl"));
m26.setText(rs.getString("paid"));
jk2.setSelectedItem(rs.getString("cust_bill"));
}
 catch(SQLException sqle)
		{
			aclip1.play();

			JOptionPane.showMessageDialog(this,"No More Record Found....","Record",JOptionPane.INFORMATION_MESSAGE,new ImageIcon("think.gif"));
		}

try
	   	 {

 String s2="id"+cid.getText();
st1 = con.createStatement();
            rss = st1.executeQuery("select * from  "+s2+"");

rss.next();
id1.setText(rss.getString("pid"));
m1.setText(rss.getString("pn"));
m2.setText(rss.getString("inp"));
m3.setText(rss.getString("pp"));
rss.next();
id2.setText(rss.getString("pid"));
m4.setText(rss.getString("pn"));
m5.setText(rss.getString("inp"));
m6.setText(rss.getString("pp"));
rss.next();
id3.setText(rss.getString("pid"));
m7.setText(rss.getString("pn"));
m8.setText(rss.getString("inp"));
m9.setText(rss.getString("pp"));
rss.next();
id4.setText(rss.getString("pid"));
m10.setText(rss.getString("pn"));
m11.setText(rss.getString("inp"));
m12.setText(rss.getString("pp"));
rss.next();
id5.setText(rss.getString("pid"));
m13.setText(rss.getString("pn"));
m14.setText(rss.getString("inp"));
m15.setText(rss.getString("pp"));
rss.next();
id6.setText(rss.getString("pid"));
m16.setText(rss.getString("pn"));
m17.setText(rss.getString("inp"));
m18.setText(rss.getString("pp"));
rss.next();
id7.setText(rss.getString("pid"));
m19.setText(rss.getString("pn"));
m20.setText(rss.getString("inp"));
m21.setText(rss.getString("pp"));
rss.next();
id8.setText(rss.getString("pid"));
m22.setText(rss.getString("pn"));
m23.setText(rss.getString("inp"));
m24.setText(rss.getString("pp"));
rss.next();

}
 catch(SQLException sqle)
		{

		}

}
if(b==del)
		{ 
try{

                                             
                                       String s2="id"+cid.getText();  

                                                      stmt=con.createStatement();
				                     stmt.executeUpdate("DROP TABLE "+s2+"");

   PreparedStatement st2 = con.prepareStatement("DELETE FROM customer WHERE cust_no = ?");
st2.setString(1,cid.getText());
st2.executeUpdate();
    aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,"Record Deleted","DELETE",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
}
catch(Exception e)
			                   {
				                    aclip1.play();
				                JOptionPane.showMessageDialog((Component) null,e,"Failed",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
			                     }
}
	        if(b==totl)
		{  
		    try
		    {
		      float a1=Integer.parseInt(m5.getText());
		      float a=Integer.parseInt(m6.getText());
              float a2=Integer.parseInt(m8.getText());
              float be=Integer.parseInt(m9.getText());
              float a3=Integer.parseInt(m11.getText());
              float c=Integer.parseInt(m12.getText());
              float a4=Integer.parseInt(m14.getText());
              float d=Integer.parseInt(m15.getText());
float a5=Integer.parseInt(m17.getText());
              float e=Integer.parseInt(m18.getText());
float a6=Integer.parseInt(m20.getText());
              float f=Integer.parseInt(m21.getText());
float a7=Integer.parseInt(m23.getText());
              float g=Integer.parseInt(m24.getText());
float a8=Integer.parseInt(m2.getText());
              float h=Integer.parseInt(m3.getText());
              float bill=(a*a1)+(be*a2)+(c*a3)+(d*a4)+(e*a5)+(f*a6)+(g*a7)+(h*a8);
              m25.setText(" "+bill);
              aclip2.play();
              /*
              c1.setEnabled(false);
              c2.setEnabled(false);
              c3.setEnabled(false);
              c4.setEnabled(false);
              m25.setEnabled(false);*/
            }
            catch(Exception e)
            {
              aclip1.play();	
              JOptionPane.showMessageDialog((Component) null,"Oh no......Please Enter The Correct Price .","Enter Correct Prise",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
	        }
	}
 }	
	public static void main(String arg[])
	{
		new Homeb("a");
	}
}  

            
            
       
