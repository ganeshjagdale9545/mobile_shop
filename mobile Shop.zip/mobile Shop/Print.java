import java.awt.*;
import java.awt.event.*;
import javax.swing.*;	
import java.applet.*;
import java.net.*;
import javax.print.*;
import javax.print.attribute.*;
import java.io.*;
import java.awt.BorderLayout;
import java.awt.event.*;
import java.io.File;										
class Print extends JFrame implements ActionListener
{
	
	JButton b1;
File  f1;
JEditorPane document;
                Container c = getContentPane();
	public Print()
	{
		super("Bill...!");
		c.setBackground(Color.green);
  f1 = new File("filename.txt");
	    document = new JEditorPane();
	    b1=new JButton("Print",new ImageIcon("printer.gif"));
	    b1.setBackground(Color.cyan);
	    b1.setForeground(Color.blue);	
       
	       
                
	 	 
	  setVisible(true);
	  setSize(700,450);
	  setLayout(null);
	  setLocation(20,25);
	  
	  bound();
	  add();
 try {
                                document.setPage(f1.toURI().toURL());
                            }
                            catch(Exception e) {
                                e.printStackTrace();
                            }	    
	    
                         
	}
	void bound()
	{
		b1.setBounds(0,0,700,30);
document.setBounds(0,30,700,400);
	}	
	void add()
	{
		add(document);
	    add(b1);
	   
	    
	    addEvent();
	}
	
	void addEvent()
	{
		b1.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton b=(JButton)ae.getSource();
		
           if(b==b1)
		{ 
		 try{
String filename = ("filename.txt"); // THIS IS THE FILE I WANT TO PRINT
PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE; // MY FILE IS .txt TYPE
PrintService printService[] =
PrintServiceLookup.lookupPrintServices(flavor, pras);
PrintService defaultService =
PrintServiceLookup.lookupDefaultPrintService();
PrintService service = ServiceUI.printDialog(null, 200, 200,
printService, defaultService, flavor, pras);
if (service != null) {
DocPrintJob job = service.createPrintJob();
FileInputStream fis = new FileInputStream(filename);
DocAttributeSet das = new HashDocAttributeSet();
Doc doc = new SimpleDoc(fis, flavor, das);
job.print(doc, pras);
Thread.sleep(10000);
}
}
catch(Exception e) {
                                e.printStackTrace();
                            }
	}  
	 }
          public static void main(String arg[])
	     {
		   new Print();
	     }
	
}