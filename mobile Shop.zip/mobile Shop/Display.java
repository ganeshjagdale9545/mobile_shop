import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.applet.*;
import java.net.*;
import java.io.*;		
import java.sql.*;

class Display extends JFrame implements ActionListener 
{   
     JLabel l1,l3,l4,labelNo,labelName,labelAddress,labelMobile,labelDate,labelTotal,labelBill;
     JButton b1,b2,buttonNext,buttonPrevious,buttonDelete;
     JTextField textFieldNo,textFieldName,textFieldAddress,textFieldMobile,textFieldDate,textFieldTotal,textFieldBill;
     AudioClip aclip,aclip1,aclip2;
     
     Container c = getContentPane();
     Statement st;
	 ResultSet rs;
     
     Display()
	{   
	   super("Records...........!!");
	   try
		{
		    aclip=Applet.newAudioClip(new URL("file:CASTANET.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		
		try
		{
		    aclip1=Applet.newAudioClip(new URL("file:GLUG.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
		}
		try
		{
		    aclip2=Applet.newAudioClip(new URL("file:ARROW.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
		}
		
		c.setBackground(Color.pink);
	     
	  l1=new JLabel(" The  Record  Of  Mobile  Billing  System :-");
	  l3=new JLabel("=======================================================================================");
	  l4=new JLabel("=======================================================================================");
	  labelNo = new JLabel("Customer Number ");
	  labelName = new JLabel("Customer Name");
	  labelAddress = new JLabel("Customer Address");
	  labelMobile = new JLabel("Customer Mobile");
	  labelDate = new JLabel("Customer Date");
	  labelTotal = new JLabel("Total Price");
	  labelBill = new JLabel("Customer Bill");
		
	 
	  l1.setForeground(Color.blue);
	  l1.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l3.setForeground(Color.red);
	  l4.setForeground(Color.red);
	  
	  b1=new JButton("Back");
	  b2=new JButton("Exit");
	  buttonNext = new JButton("Next");
	  buttonPrevious = new JButton("Previous");
	  buttonDelete = new JButton("Delete");
		
	  b1.setBackground(Color.cyan);
	  b1.setForeground(Color.black);	
      b2.setBackground(Color.cyan);
	  b2.setForeground(Color.black);	
	  buttonNext.setBackground(Color.cyan);
	  buttonPrevious.setBackground(Color.cyan);
	  buttonDelete.setBackground(Color.cyan);
		
	   textFieldNo = new JTextField();
	   textFieldName = new JTextField();
	   textFieldAddress = new JTextField();
	   textFieldMobile = new JTextField();
	   textFieldDate = new JTextField();
	   textFieldTotal = new JTextField();
	   textFieldBill = new JTextField();
		
		textFieldNo.setBackground(Color.yellow);
		textFieldName.setBackground(Color.yellow);
		textFieldAddress.setBackground(Color.yellow);
		textFieldMobile.setBackground(Color.yellow);
		textFieldDate.setBackground(Color.yellow);
		textFieldTotal.setBackground(Color.yellow);
		textFieldBill.setBackground(Color.yellow);
		
	    setSize(500,500);
	    setLocation(250,100);
	    setLayout(null);
	    setVisible(true);
	    
	    l1.setBounds(20,25,600,30);
	    l3.setBounds(2,65,600,30);
	    l4.setBounds(2,315,600,30);
	    labelNo.setBounds(50,102,140,20);
	  labelName.setBounds(50,132,140,20);
	  labelAddress.setBounds(50,162,140,20);
	  labelMobile.setBounds(50,192,140,20);
	  labelDate.setBounds(50,222,140,20);
	  labelTotal.setBounds(50,252,140,20);
	  labelBill.setBounds(50,282,140,20);
	  
	    b1.setBounds(50,370,80,25);
	    b2.setBounds(170,370,80,25);
	    buttonNext.setBounds(370,130,100,25);
	  buttonPrevious.setBounds(370,160,100,25);
	  buttonDelete.setBounds(370,190,100,25);	
	  
	    
		textFieldNo.setBounds(170,100,160,25);
		textFieldName.setBounds(170,130,160,25);
		textFieldAddress.setBounds(170,160,160,25);
		textFieldMobile.setBounds(170,190,160,25);
		textFieldDate.setBounds(170,220,160,25);
		textFieldTotal.setBounds(170,250,160,25);
		textFieldBill.setBounds(170,280,160,25);
		
		textFieldNo.setEditable(false);
		textFieldName.setEditable(false);
		textFieldAddress.setEditable(false);
		textFieldMobile.setEditable(false);
		textFieldDate.setEditable(false);
		textFieldTotal.setEditable(false);
	    textFieldBill.setEditable(false);
	
	      add(l1);
	      add(l3);
	      add(l4);
	      add(labelNo);
		  add(labelName);
		   add(labelAddress);
		  add(labelMobile);
		  add(labelDate);
		  add(labelTotal);
	      add(labelBill);
		
	      add(b1);
	      add(b2);
	      add(buttonNext);
		  add(buttonPrevious);
		  add(buttonDelete);
		  b1.setMnemonic('b');
	      b1.setToolTipText("Press 'Alt+b'To Go  Home  Page"); 
	      b2.setMnemonic('e');
	      b2.setToolTipText("Press 'Alt+e'To Exit  From  The System");
	        buttonNext.setMnemonic('n');
	      buttonNext.setToolTipText("Press 'Alt+n'");
	      buttonPrevious.setMnemonic('p');
	      buttonPrevious.setToolTipText("Press 'Alt+p'");
	      buttonDelete.setMnemonic('d');
	      buttonDelete.setToolTipText("Press 'Alt+d'");
	      
		add(textFieldNo);
		add(textFieldName);
		add(textFieldAddress);
		add(textFieldMobile);
		add(textFieldDate);
		add(textFieldTotal);
		add(textFieldBill);
		
		try
		{
			  Class.forName("com.mysql.jdbc.Driver");
	            Connection   con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");
			
			String query = "select * from customer";
			st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            rs = st.executeQuery(query);
		}

		catch(ClassNotFoundException cnfe)
		{
			System.out.println(cnfe);
		}

		catch(SQLException sqle)
		{
			System.out.println(sqle);
		}

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		b1.addActionListener(this);
	   	b2.addActionListener(this);
	   	
	   	buttonNext.addActionListener(this);
		buttonPrevious.addActionListener(this);
	    buttonDelete.addActionListener(this);
	
	 }
	   
	   public void actionPerformed(ActionEvent ae)
	   {
	   	 JButton b=(JButton)ae.getSource();
	   	 if(b==b1)
	   	 {
	   	 	aclip.play();
	   	 	
                           setVisible(false);
	   	 }
	   	 if(b==b2)
	   	 {
	   	 	aclip1.play();
	   	 	
	   	 	new Exit();
	   	 	
	   	 }
	   	 
	   	 try
	   	 {
	   	  if(b==buttonNext)
	   	    {
	   	 	    textFieldNo.setEditable(false);
				textFieldName.setEditable(false);
				textFieldAddress.setEditable(false);
				textFieldMobile.setEditable(false);
				textFieldDate.setEditable(false);
				textFieldTotal.setEditable(false);
				textFieldBill.setEditable(false);
				
                 rs.next();
                 aclip2.play();
				textFieldNo.setText(rs.getInt("cust_no") + "");
				textFieldName.setText(rs.getString("cust_name"));
				textFieldAddress.setText(rs.getString("cust_add") + "");
				textFieldMobile.setText(rs.getString("cust_mo"));
				textFieldDate.setText(rs.getString("cust_date") + "");
				textFieldTotal.setText(rs.getInt("cust_totl") + "");
				textFieldBill.setText(rs.getString("cust_bill") + "");
				
		    }
	   	 }
	   	 catch(SQLException sqle)
		{
			aclip1.play();
			JOptionPane.showMessageDialog(this,"No Next Record Found....","Record",JOptionPane.INFORMATION_MESSAGE,new ImageIcon("think.gif"));
		}
		
		try
		{
		
	   	    if(b==	buttonPrevious)
	   	     {
	   	     	textFieldNo.setEditable(false);
				textFieldName.setEditable(false);
				textFieldAddress.setEditable(false);
				textFieldMobile.setEditable(false);
			    textFieldDate.setEditable(false);
				textFieldTotal.setEditable(false);

                rs.previous();
                 aclip2.play();
				textFieldNo.setText(rs.getInt("cust_no") + "");
				textFieldName.setText(rs.getString("cust_name"));
				textFieldAddress.setText(rs.getString("cust_add") + "");
				textFieldMobile.setText(rs.getString("cust_mo"));
				textFieldDate.setText(rs.getString("cust_date") + "");
				textFieldTotal.setText(rs.getString("cust_totl") + "");
			
	   	     }
	   	 }
	   	 catch(SQLException sqle)
		{
			aclip1.play();
			JOptionPane.showMessageDialog(this,"No Previous Record Found....","Record",JOptionPane.INFORMATION_MESSAGE,new ImageIcon("think.gif"));
		}
		
		try
		{
		   
	   	 if(b==	buttonDelete)
	   	  {
	   	 	    aclip1.play();
	   	 		String MemberId = textFieldNo.getText();
                st.executeUpdate("delete from customer where cust_no = " + MemberId);
                JOptionPane.showMessageDialog(this,"Record Deleted...","Confirmation",JOptionPane.INFORMATION_MESSAGE);
                rs = st.executeQuery("select * from customer");
	   	  }
	   	 }
	   	 catch(SQLException sqle)
		{
			aclip1.play();
			JOptionPane.showMessageDialog(this,"Couldn't Delete the Record....","Deletion Of Record",JOptionPane.INFORMATION_MESSAGE);
		}
	   }	
	
	public static void main(String arg[])
	{
		Display dataBase = new Display();
	}
}		
