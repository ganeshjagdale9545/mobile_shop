import java.awt.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.font.*;
import java.lang.String.*;
import java.util.*;
import java.text.*;
import java.sql.*;		
import java.awt.Graphics.*;
import javax.imageio.*;
import java.net.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

 

class OpenRecord extends JFrame implements ActionListener
{
	
	JButton b1,b2,b3;
	
	JTable table;
JTextField stext;

	String[] colmn={"Customer Number","Customer Name","Customer Address","Customer Mobile","Date","Total","Bill","Amount"};
	
	String[][] data=new String[100][8];
	JScrollPane scrollpane ;
	Font f=new Font("Bookman Old Style",Font.BOLD, 15);
    
    AudioClip aclip,aclip1,aclip2;
  
     OpenRecord()
	{
		super("Record Of Mobile Billing System......!!");
		b1=new JButton("Back");
		b2=new JButton("Exit");
                b3=new JButton("Search");
                 stext=new JTextField("");
		try
		{
		   aclip=Applet.newAudioClip(new URL("file:CASTANET.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		try
		{
		   aclip1=Applet.newAudioClip(new URL("file:GLUG.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		try
		{
		   aclip2=Applet.newAudioClip(new URL("file:ARROW.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		
				
						b1.setFont(new Font("Bookman Old Style",Font.BOLD, 15));
						b2.setFont(new Font("Bookman Old Style",Font.BOLD, 15));
	
						
		b1.setForeground(Color.blue);
		b2.setForeground(Color.blue);
		b1.setBackground(Color.cyan);
		b2.setBackground(Color.cyan);
				b3.setForeground(Color.blue);
		b3.setBackground(Color.cyan);
		this.setSize(1280,700);
		
		this.setLayout(null);	
					  stext.setBounds(275,620,100,25);
					  b3.setBounds(395,620,80,25);
					  b2.setBounds(595,620,80,25);
					  b1.setBounds(495,620,80,25);
					  try
						{	
						  Class.forName("com.mysql.jdbc.Driver");
	                       Connection   cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");
							Statement s=cn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
							ResultSet rs;						
					
							String st="select * from customer";
						    rs=s.executeQuery(st);
							int i=0;
							while(rs.next())
								{
//rs.previous();
									String no=rs.getString(1);
									String name=rs.getString(2);
								    String address=rs.getString(3);
									String mobile=rs.getString(4);
									String date=rs.getString(5);
									String total=rs.getString(6);
									String bill=rs.getString(7);
                                                                        String amount=rs.getString(8);
									
														
											data[i][0]=no;
											data[i][1]=name;
											data[i][2]=address;
											data[i][3]=mobile;
											data[i][4]=date;
											data[i][5]=total;
											data[i][6]=bill;
                                                                                        data[i][7]=amount;
											i++;
									}
								}
									catch(Exception ee)
									{
									}

					  
                                                    table=new JTable(data,colmn);
												   	table.setEnabled(false);
												   	table.setFont(f);
												   	table.setForeground(Color.magenta);
											        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
											       	int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
											     	scrollpane = new JScrollPane(table,v,h);
                                                                                                scrollpane.setBounds(10,10,1100,600);
											     	this.add(scrollpane);
									  
            this.add(b1);
            b1.setMnemonic('b');
            b1.setToolTipText("Press 'Alt+b' To Go Home");
			this.add(b2);
			b2.setMnemonic('e');
            b2.setToolTipText("Press 'Alt+e' To Go Home");
		this.add(b3);
add(stext);
		
			
						b1.addActionListener(this);
						b2.addActionListener(this);
						b3.addActionListener(this);						
						this.setLocationRelativeTo(null);
	
		
		this.setVisible(true);
    }	
    
    public void actionPerformed(ActionEvent ae)
    {
    	if(ae.getSource()==b1)
    	{   
    	    aclip.play();
    		//new Home();
    			this.setVisible(false);
    	}
    	if(ae.getSource()==b2)
    	{              
    	                    aclip1.play();
    						new Exit();
		}
if(ae.getSource()==b3)
    	{              
    	                    aclip1.play();





    						
try (BufferedWriter bw = new BufferedWriter(new FileWriter("JButtonTableExample.java"))) {

String newLine = System.getProperty("line.separator");
 bw.write("import java.awt.*;import java.awt.event.*;import javax.swing.*;import javax.swing.table.*;public class JButtonTableExample extends JFrame {public JButtonTableExample(){super( \"JButtonTable Example\" );DefaultTableModel dm = new DefaultTableModel();");
bw.newLine();
bw.write("dm.setDataVector(new Object[][]{");


						try{	
						  Class.forName("com.mysql.jdbc.Driver");
	                       Connection   cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");
							Statement s=cn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
							ResultSet rs;						
					
			String st="select * from customer where cust_no='"+stext.getText()+"' or cust_name='"+stext.getText()+"' or cust_add='"+stext.getText()+"' or cust_mo='"+stext.getText()+"' or cust_date='"+stext.getText()+"' or cust_bill='"+stext.getText()+"'";
						    rs=s.executeQuery(st);



int i=0;
							while(rs.next())
								{

									String no=rs.getString(1);
									String name=rs.getString(2);
								    String address=rs.getString(3);
									String mobile=rs.getString(4);
									String date=rs.getString(5);
									String total=rs.getString(6);
									String bill=rs.getString(7);
                                                                        String amount=rs.getString(8);
if(i!=0){
bw.write(",{\""+no+"\",\""+name+"\",\""+address+"\",\""+mobile+"\",\""+total+"\",\""+bill+"\",\""+amount+"\"}");
}
else
{
bw.write("{\""+no+"\",\""+name+"\",\""+address+"\",\""+mobile+"\",\""+total+"\",\""+bill+"\",\""+amount+"\"}");
}
i++;
									}

}
									catch(Exception ee)
									{
									}							
bw.write("},new Object[]{\"ID\",\"NAME\",\"ADDRESS\",\"MOBILE\",\"TOTAL\",\"BILL\",\"AMOUNT\"});");
bw.newLine();
bw.write("JTable table = new JTable(dm);table.getColumn(\"NAME\").setCellRenderer(new ButtonRenderer());table.getColumn(\"NAME\").setCellEditor(new ButtonEditor(new JCheckBox()));JScrollPane scroll = new JScrollPane(table);getContentPane().add( scroll );setSize( 1200, 700 );setVisible(true);}public static void main(String[] args) {JButtonTableExample frame = new JButtonTableExample();frame.addWindowListener(new WindowAdapter() {public void windowClosing(WindowEvent e) {System.exit(0);}});}}");
}catch (IOException e) {

			e.printStackTrace();

		}



		Runtime rt = Runtime.getRuntime();
try {
			Process proc = rt.exec("java CrunchifyCommandJava");
} catch (IOException e) {
			e.printStackTrace();
} 
		}
    	
    }
    
    public static void main(String str[])
    {
    	new OpenRecord();
    }
}		
