import java.awt.*;
import javax.swing.*;
import java.sql.*;
class AllDelete extends JFrame 
{   
    Connection cn;
	Statement st;
	ResultSet rs;
    AllDelete()
	{   
	     try
	  {
		
		 Class.forName("com.mysql.jdbc.Driver");
	    cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");
		st = cn.createStatement();
		rs = st.executeQuery("delete * from customer");
		JOptionPane.showMessageDialog((Component) null,"Congradulation...Your  Record Is Deleted..","Deleted.......!!",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
			                     
	  }
	   catch(Exception e)
	   {
	   	JOptionPane.showMessageDialog((Component) null,"Congradulation...Your  Record Is Deleted..","Deleted.......!!",JOptionPane.PLAIN_MESSAGE,new ImageIcon("flower.gif"));
		
	   }	
	}
	public static void main(String arg[])
	{
		new AllDelete();
	}
}