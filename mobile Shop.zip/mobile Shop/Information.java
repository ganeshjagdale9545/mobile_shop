import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;	
import java.applet.*;
import java.net.*;		
								
class Information  extends JFrame implements ActionListener
{
	JLabel l,l1,l2,l3,l4,l5,l6,l7,l8;
	JButton b1,b2;
	AudioClip aclip,aclip1;
	Container c = getContentPane();
	
	public Information()
	{
		super("Information About  Software  Developer....!");
                c.setBackground(Color.pink);
		try
		{
		    aclip=Applet.newAudioClip(new URL("file:CASTANET.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		
		try
		{
		    aclip1=Applet.newAudioClip(new URL("file:GLUG.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
		}
	  l=new JLabel("Welcome  To  Mobile  Billing  System.");
	  l1=new JLabel("This  software  is  developed  by Shaikh Saif , Shaikh Aman  ");
	  l2=new JLabel(" Pardeshi Achal and Gaikawad Prasad at  the  late  of 2019 in  the");
	  l3=new JLabel(" A.I.E.T.P. Collage Ashoknagar , shrirampur . He  completed  her ");
	  l4=new JLabel(" Project  in  the year 2018-2019 .For  more help");
      l5=new JLabel(" and  information  contact the current  system  user .");
      l6=new JLabel("Shaikh Aman");
      l7=new JLabel("");
      l8=new JLabel("&");
	  
	  l.setForeground(Color.black);
	  l.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l1.setForeground(Color.red);
	  l1.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l2.setForeground(Color.red);
	  l2.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l3.setForeground(Color.red);
	  l3.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l4.setForeground(Color.red);
	  l4.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l5.setForeground(Color.red);
	  l5.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l6.setForeground(Color.red);
	  l6.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l7.setForeground(Color.red);
	  l7.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  l8.setForeground(Color.red);
	  l8.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,20));
	  
	  b1=new JButton("Back");
	  b2=new JButton("Exit");
	  b1.setBackground(Color.cyan);
	  b1.setForeground(Color.blue);	
      b2.setBackground(Color.cyan);
	  b2.setForeground(Color.blue);	
	 	 
	  setVisible(true);
	  setSize(900,500);
	  setLayout(null);
	  setLocation(100,100);
	  
	  bound();
	  add();
	}
	void bound()
	{
		l.setBounds(75,30,500,25);
		l1.setBounds(125,80,600,25);
		l2.setBounds(125,105,600,20);
		l3.setBounds(125,130,600,25);
		l4.setBounds(125,155,600,25);
		l5.setBounds(125,180,600,25);
		l6.setBounds(375,230,600,25);
		l7.setBounds(375,290,600,25);
		l8.setBounds(400,260,600,25);
		
		b1.setBounds(200,340,75,25);
		b2.setBounds(300,340,75,25);
		
	}
	void add()
	{
		add(l);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
		add(l6);
		add(l7);
		add(l8);
	    add(b1);
	    add(b2);
	    b1.setMnemonic('b');
	    b1.setToolTipText("Press 'Alt+b'To Go  Home  Page");
	    b2.setMnemonic('e');
	    b2.setToolTipText("Press 'Alt+e'To Exit  From  The System");
	  
	    addEvent();
	}
	
	void addEvent()
	{
		b1.addActionListener(this);
		b2.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton b=(JButton)ae.getSource();
		if(b==b1)
		{
			aclip.play();
			
		     new Home();
		 setVisible(false);
		}
		
		if(b==b2)
		{ 
		   aclip1.play();
		  
		     new Exit();
		    
	    }
	  }
          public static void main(String arg[])
	     {
		   new Information();
	     }
	
}
