import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class ChangePassword extends JFrame implements ActionListener
{   
 JLabel l1,l2,l3,l4,l5,ln;
      JButton b1,b2;
      JTextField t1;
      JPasswordField ps1,ps2,ps3; 
     Connection cn;
	 Font F1=new Font("Times New Roman",Font.BOLD,14);
     ChangePassword()
     {
       setVisible(true);
       setSize(1500,1500);
       setTitle("Welcome to Mobile Management system");
     getContentPane().setBackground(Color.cyan);
       setLayout(new BorderLayout());
     ln = new JLabel("                  	   To Change Password");
     ln.setForeground(Color.red);
	 ln.setBackground(Color.cyan);
	     ln.setFont(new Font("Times New Roman",Font.BOLD,72));	   
      add(ln,BorderLayout.NORTH);
      l1=new JLabel("Enter Current Username");
	  l1.setFont(F1);
	  l1.setForeground(Color.blue);
      l2=new JLabel("Enter Current Password");
	  l2.setFont(F1);
	  l2.setForeground(Color.blue);
      l3=new JLabel("Enter New Password");
	  l3.setFont(F1);
	  l3.setForeground(Color.blue);
      l4=new JLabel("Re-enter New Password");
	  l4.setFont(F1);
	  l4.setForeground(Color.blue);
 
     t1=new JTextField(10);
	 t1.setFont(F1);
     ps1=new JPasswordField(10);
	 ps1.setFont(F1);
     ps2=new JPasswordField(10);
	 ps2.setFont(F1);
     ps3=new JPasswordField(10);
	 ps3.setFont(F1);
     b1=new JButton("OK");
	 b1.setFont(F1);
	 b1.setForeground(Color.blue);
     b2=new JButton("BACK");
	 b2.setFont(F1);
	 b2.setForeground(Color.blue);
     JPanel p1=new JPanel();
      p1.setLayout(new GridLayout(5,3,30,30));
      p1.add(l1);
      p1.add(t1);
      p1.add(l2);
      p1.add(ps1);
      p1.add(l3);
      p1.add(ps2);
      p1.add(l4);
      p1.add(ps3);
      p1.add(b1);
      p1.add(b2);
	  p1.setBackground(Color.cyan);
	  p1.setBounds(300,200,400,500);
     JPanel p2=new JPanel();
	  p2.setBounds(300,200,400,500);
      p2.add(p1);
	  
     b1.addActionListener(this);
     b2.addActionListener(this);
     add(p2,BorderLayout.CENTER);
     doLayout();
      validate();
      p1.setBackground(Color.cyan);
        p2.setBackground(Color.cyan);       
      t1.requestFocus();
   try
     {
        Class.forName("com.mysql.jdbc.Driver");
	         cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobile","root","root");

      }
    catch(Exception e)
    {
      JOptionPane.showMessageDialog(this,"Error is"+e);
    }
      }
     public void actionPerformed(ActionEvent ae)
     {
        if(ae.getSource()==b1)
        {
            if((t1.getText().trim().length()>7))
           {
              JOptionPane.showMessageDialog(this,"Enter user name less than 7");
               t1.requestFocus();
               return;
            }
            if((ps1.getText().trim().length()>7))
           {
              JOptionPane.showMessageDialog(this,"Enter current password  less than 7");
               ps1.requestFocus();               return;
            }
            if((ps2.getText().trim().length()>7))
           {
              JOptionPane.showMessageDialog(this,"Enter new  password less than 7");
                           ps2.requestFocus();   return;
            }
            if((ps3.getText().trim().length()>7))
           {
              JOptionPane.showMessageDialog(this,"Enter new password less than 7");
                           ps3.requestFocus();   return;
            }
           try
           {
          cn.setAutoCommit(false);
         Statement st=cn.createStatement();
     ResultSet rs=st.executeQuery("Select PASSWORD from pass where USERNAME='"+t1.getText()+"'");
      if(rs.next())
      {
        if(rs.getString(1).equals(ps1.getText()))
          { 

             if(ps2.getText().equals(ps3.getText()))
             {
                    Statement st1=cn.createStatement();           
                     int t=st1.executeUpdate("update pass set PASSWORD='"+ps2.getText()+"' where USERNAME='"+t1.getText()+"'");
      int k=JOptionPane.showConfirmDialog(this,"Do you want to save changes?","Confirmation",JOptionPane.YES_NO_OPTION);
           if(k==0)
           {
            cn.commit();
          
            JOptionPane.showMessageDialog(this,"Password is updated");
          dispose();
          new Login();
        
}
            else
             cn.rollback();
              }
              else
          JOptionPane.showMessageDialog(this,"New Password should be same");
        }        
           
           else
         JOptionPane.showMessageDialog(this,"Invalid Password");
      }
      else
       JOptionPane.showMessageDialog(this,"Invalid Uname");
      }    
   
   
            catch(Exception e)
           {
              JOptionPane.showMessageDialog(this,""+e);  
           }
        }
        else
        if(ae.getSource()==b2)
       {
         dispose();
         
         new Home();
         }
     }
    public static void main(String args[])
     {
       new ChangePassword();
     }
}

