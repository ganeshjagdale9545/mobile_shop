import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.applet.*;
import java.net.*;												
class Thanks extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JButton b1;
	AudioClip aclip,aclip1;
 		Container c = getContentPane();
 		
 	Thanks()
	{
		super("Thanks...!");
		c.setBackground(Color.green);
		 try
		{
		    aclip=Applet.newAudioClip(new URL("file:CASTANET.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		}
		
		try
		{
		    aclip1=Applet.newAudioClip(new URL("file:GLUG.wav"));
		}
	    catch(Exception e)
		{
			JOptionPane.showMessageDialog((Component) null,"Oh no...... Error Occured During Playing Audio.","Invallid  Audio",JOptionPane.PLAIN_MESSAGE,new ImageIcon("think.gif"));
		
		}
		l1=new JLabel("Thanks  For  Choosing  Mobile Billing  System");
		l2=new JLabel("Click   OK  To  Exit");
		
		b1=new JButton("OK");
		
		
		l1.setForeground(Color.blue);
		l1.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,30));
		l2.setForeground(Color.blue);
		l2.setFont(new Font("Georgia",Font.BOLD|Font.ITALIC,25));
		b1.setBackground(Color.cyan);
		
		b1.setForeground(Color.blue);
		
		
		setVisible(true);
		setSize(900,400);
		setLayout(null);
		setLocation(60,60);
		bound();
		add();
		
	}
	void bound()
	{
		l1.setBounds(80,50,800,30);
		l2.setBounds(80,130,500,30);
		
                b1.setBounds(100,250,105,25);
		
	
	}
	void add()
	{
		add(l1);
		add(l2);
		 
		add(b1);
	
	    b1.setMnemonic('o');
	    b1.setToolTipText("Press 'Alt+o'To Exit");
	   
	  
		 addEvent();
	}
	
	void addEvent()
	{
		b1.addActionListener(this);
		
	
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton b=(JButton)ae.getSource();
		
	
		if(b==b1)
		{
			aclip1.play();
			
			System.exit(0);
			setVisible(false);
	     }
	}

        public static void main(String args[])
	{
		new Thanks();
	}
}
