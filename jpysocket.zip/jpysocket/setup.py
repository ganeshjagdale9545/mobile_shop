import setuptools
 
with open("README.md", "r") as fh:
    long_description = fh.read()
 
setuptools.setup(
    #Here is the module name.
    name="jpysocket",
 
    #version of the module
    version="1.1.5",
 
    #Name of Author
    author="Ganesh Jagdale",
 
    #your Email address
    author_email="jagdaleganesh9545@gmail.com",
 
    #Small Description about module
    description="Decode The String Received From Java Socket And Encode The String for Send To The Java Socket. Connect Python And Java Sockets",
 
    long_description=long_description,
 
    #Specifying that we are using markdown file for description
    long_description_content_type="text/markdown",
 
    #Any link to reach this module, if you have any webpage or github profile
    url="",
    packages=setuptools.find_packages(),
 
    #classifiers like program is suitable for python3, just leave as it is.
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
